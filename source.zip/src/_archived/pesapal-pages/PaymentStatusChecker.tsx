
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { usePaymentStatus } from '@/hooks/usePaymentStatus';
import { toast } from '@/hooks/use-toast';

export function PaymentStatusChecker() {
  const [orderTrackingId, setOrderTrackingId] = useState('');
  const { checkPaymentStatus, loading } = usePaymentStatus();

  const handleCheck = async () => {
    if (!orderTrackingId.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter the order tracking ID",
        variant: "destructive"
      });
      return;
    }

    const success = await checkPaymentStatus(orderTrackingId.trim());
    
    if (success) {
      // Refresh the page to show updated subscription status
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Check Payment Status</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Input
            placeholder="Enter your order tracking ID"
            value={orderTrackingId}
            onChange={(e) => setOrderTrackingId(e.target.value)}
          />
        </div>
        <Button 
          onClick={handleCheck} 
          disabled={loading || !orderTrackingId.trim()}
          className="w-full"
        >
          {loading ? 'Checking...' : 'Check Payment Status'}
        </Button>
        <p className="text-sm text-muted-foreground">
          If your payment went through but your subscription isn't active, use this tool to verify and activate it.
        </p>
      </CardContent>
    </Card>
  );
}
