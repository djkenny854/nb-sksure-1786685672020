export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      ad_clicks: {
        Row: {
          ad_id: string
          clicked_at: string
          id: string
          ip_address: unknown
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          ad_id: string
          clicked_at?: string
          id?: string
          ip_address?: unknown
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          ad_id?: string
          clicked_at?: string
          id?: string
          ip_address?: unknown
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ad_clicks_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_roles: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          role: Database["public"]["Enums"]["admin_role"]
          user_id: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["admin_role"]
          user_id?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["admin_role"]
          user_id?: string | null
        }
        Relationships: []
      }
      ads: {
        Row: {
          click_count: number
          created_at: string
          created_by: string | null
          description: string | null
          end_date: string
          id: string
          image_url: string | null
          impression_count: number
          is_active: boolean
          link_url: string | null
          start_date: string
          target_audience: string
          title: string
          updated_at: string
        }
        Insert: {
          click_count?: number
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date: string
          id?: string
          image_url?: string | null
          impression_count?: number
          is_active?: boolean
          link_url?: string | null
          start_date?: string
          target_audience?: string
          title: string
          updated_at?: string
        }
        Update: {
          click_count?: number
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string
          id?: string
          image_url?: string | null
          impression_count?: number
          is_active?: boolean
          link_url?: string | null
          start_date?: string
          target_audience?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      email_notifications: {
        Row: {
          content: string
          created_at: string
          id: string
          sent_at: string | null
          status: string | null
          subject: string
          type: string
          user_id: string | null
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          sent_at?: string | null
          status?: string | null
          subject: string
          type: string
          user_id?: string | null
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          sent_at?: string | null
          status?: string | null
          subject?: string
          type?: string
          user_id?: string | null
        }
        Relationships: []
      }
      free_ticket_matches: {
        Row: {
          created_at: string | null
          free_ticket_id: string
          id: string
          match_name: string
          match_time: string
          odds: string
          prediction: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          free_ticket_id: string
          id?: string
          match_name: string
          match_time: string
          odds: string
          prediction: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          free_ticket_id?: string
          id?: string
          match_name?: string
          match_time?: string
          odds?: string
          prediction?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "free_ticket_matches_free_ticket_id_fkey"
            columns: ["free_ticket_id"]
            isOneToOne: false
            referencedRelation: "free_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      free_tickets: {
        Row: {
          betika_link: string | null
          betpawa_link: string | null
          comments: string | null
          created_at: string
          created_by: string | null
          id: string
          image_url: string | null
          match_count: number | null
          status: string
          ticket_name: string
          updated_at: string
        }
        Insert: {
          betika_link?: string | null
          betpawa_link?: string | null
          comments?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          image_url?: string | null
          match_count?: number | null
          status?: string
          ticket_name?: string
          updated_at?: string
        }
        Update: {
          betika_link?: string | null
          betpawa_link?: string | null
          comments?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          image_url?: string | null
          match_count?: number | null
          status?: string
          ticket_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      notification_broadcasts: {
        Row: {
          created_at: string | null
          id: string
          message: string
          sent_to_count: number
          title: string
          type: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          message: string
          sent_to_count?: number
          title: string
          type?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          message?: string
          sent_to_count?: number
          title?: string
          type?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      notification_templates: {
        Row: {
          created_at: string | null
          id: string
          message: string
          name: string
          title: string
          type: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          message: string
          name: string
          title: string
          type?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          message?: string
          name?: string
          title?: string
          type?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          is_system_generated: boolean
          message: string
          title: string
          type: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          is_system_generated?: boolean
          message: string
          title: string
          type?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          is_system_generated?: boolean
          message?: string
          title?: string
          type?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      nylonpay_transactions: {
        Row: {
          amount_ugx: number
          created_at: string
          currency: string
          description: string | null
          error: string | null
          id: string
          metadata: Json | null
          method: string | null
          nylonpay_transaction_id: string | null
          package_id: string | null
          phone_number: string
          provider: string | null
          reference: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_ugx: number
          created_at?: string
          currency?: string
          description?: string | null
          error?: string | null
          id?: string
          metadata?: Json | null
          method?: string | null
          nylonpay_transaction_id?: string | null
          package_id?: string | null
          phone_number: string
          provider?: string | null
          reference: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_ugx?: number
          created_at?: string
          currency?: string
          description?: string | null
          error?: string | null
          id?: string
          metadata?: Json | null
          method?: string | null
          nylonpay_transaction_id?: string | null
          package_id?: string | null
          phone_number?: string
          provider?: string | null
          reference?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "nylonpay_transactions_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
        ]
      }
      package_deletion_logs: {
        Row: {
          confirmation_text: string
          created_at: string
          deleted_by: string
          id: string
          package_id: string
          package_name: string
        }
        Insert: {
          confirmation_text: string
          created_at?: string
          deleted_by: string
          id?: string
          package_id: string
          package_name: string
        }
        Update: {
          confirmation_text?: string
          created_at?: string
          deleted_by?: string
          id?: string
          package_id?: string
          package_name?: string
        }
        Relationships: []
      }
      packages: {
        Row: {
          created_at: string
          description: string | null
          duration_days: number
          grace_period_days: number
          id: string
          max_devices: number | null
          name: string
          prevent_account_sharing: boolean | null
          price_ugx: number
          status: Database["public"]["Enums"]["package_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          duration_days: number
          grace_period_days?: number
          id?: string
          max_devices?: number | null
          name: string
          prevent_account_sharing?: boolean | null
          price_ugx: number
          status?: Database["public"]["Enums"]["package_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          duration_days?: number
          grace_period_days?: number
          id?: string
          max_devices?: number | null
          name?: string
          prevent_account_sharing?: boolean | null
          price_ugx?: number
          status?: Database["public"]["Enums"]["package_status"]
          updated_at?: string
        }
        Relationships: []
      }
      payment_error_logs: {
        Row: {
          created_at: string | null
          error_details: Json | null
          error_message: string
          error_type: string
          function_name: string | null
          id: string
          transaction_id: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          error_details?: Json | null
          error_message: string
          error_type: string
          function_name?: string | null
          id?: string
          transaction_id?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          error_details?: Json | null
          error_message?: string
          error_type?: string
          function_name?: string | null
          id?: string
          transaction_id?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount_ugx: number
          approved_at: string | null
          approved_by: string | null
          created_at: string
          id: string
          package_id: string | null
          payment_method: string | null
          status: Database["public"]["Enums"]["payment_status"]
          transaction_id: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          amount_ugx: number
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          package_id?: string | null
          payment_method?: string | null
          status?: Database["public"]["Enums"]["payment_status"]
          transaction_id?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          amount_ugx?: number
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          package_id?: string | null
          payment_method?: string | null
          status?: Database["public"]["Enums"]["payment_status"]
          transaction_id?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payments_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
        ]
      }
      pesapal_transactions: {
        Row: {
          amount_ugx: number
          api_version: string | null
          callback_url: string | null
          cancellation_url: string | null
          created_at: string
          currency: string | null
          description: string | null
          id: string
          last_error: string | null
          merchant_reference: string | null
          notification_id: string | null
          order_tracking_id: string | null
          package_id: string | null
          payment_method: string | null
          payment_status_description: string | null
          pesapal_response: Json | null
          pesapal_tracking_id: string | null
          phone_number: string
          retry_count: number | null
          status: string
          token_used: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          amount_ugx: number
          api_version?: string | null
          callback_url?: string | null
          cancellation_url?: string | null
          created_at?: string
          currency?: string | null
          description?: string | null
          id?: string
          last_error?: string | null
          merchant_reference?: string | null
          notification_id?: string | null
          order_tracking_id?: string | null
          package_id?: string | null
          payment_method?: string | null
          payment_status_description?: string | null
          pesapal_response?: Json | null
          pesapal_tracking_id?: string | null
          phone_number: string
          retry_count?: number | null
          status?: string
          token_used?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          amount_ugx?: number
          api_version?: string | null
          callback_url?: string | null
          cancellation_url?: string | null
          created_at?: string
          currency?: string | null
          description?: string | null
          id?: string
          last_error?: string | null
          merchant_reference?: string | null
          notification_id?: string | null
          order_tracking_id?: string | null
          package_id?: string | null
          payment_method?: string | null
          payment_status_description?: string | null
          pesapal_response?: Json | null
          pesapal_tracking_id?: string | null
          phone_number?: string
          retry_count?: number | null
          status?: string
          token_used?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pesapal_transactions_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          is_banned: boolean | null
          max_devices: number | null
          phone: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          is_banned?: boolean | null
          max_devices?: number | null
          phone?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          is_banned?: boolean | null
          max_devices?: number | null
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      pwa_cache: {
        Row: {
          cache_data: Json
          cache_key: string
          created_at: string
          expires_at: string
          id: string
          updated_at: string
        }
        Insert: {
          cache_data: Json
          cache_key: string
          created_at?: string
          expires_at: string
          id?: string
          updated_at?: string
        }
        Update: {
          cache_data?: Json
          cache_key?: string
          created_at?: string
          expires_at?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      subscription_alerts: {
        Row: {
          alert_type: string
          created_at: string
          days_before_expiry: number
          id: string
          is_sent: boolean
          message: string
          sent_at: string | null
          subscription_id: string
          user_id: string
        }
        Insert: {
          alert_type?: string
          created_at?: string
          days_before_expiry: number
          id?: string
          is_sent?: boolean
          message: string
          sent_at?: string | null
          subscription_id: string
          user_id: string
        }
        Update: {
          alert_type?: string
          created_at?: string
          days_before_expiry?: number
          id?: string
          is_sent?: boolean
          message?: string
          sent_at?: string | null
          subscription_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscription_alerts_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "user_subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_extensions: {
        Row: {
          created_at: string
          created_by: string | null
          days_added: number
          id: string
          reason: string | null
          subscription_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          days_added: number
          id?: string
          reason?: string | null
          subscription_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          days_added?: number
          id?: string
          reason?: string | null
          subscription_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscription_extensions_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "user_subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      support_messages: {
        Row: {
          admin_response: string | null
          created_at: string
          email: string
          full_name: string | null
          id: string
          message: string
          priority: string
          responded_at: string | null
          responded_by: string | null
          status: string
          subject: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          admin_response?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          id?: string
          message: string
          priority?: string
          responded_at?: string | null
          responded_by?: string | null
          status?: string
          subject: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          admin_response?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          message?: string
          priority?: string
          responded_at?: string | null
          responded_by?: string | null
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      system_settings: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          key: string
          updated_at: string | null
          value: Json
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          key: string
          updated_at?: string | null
          value: Json
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          key?: string
          updated_at?: string | null
          value?: Json
        }
        Relationships: []
      }
      ticket_matches: {
        Row: {
          created_at: string | null
          id: string
          match_name: string
          match_time: string
          odds: string
          prediction: string
          ticket_id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          match_name: string
          match_time: string
          odds: string
          prediction: string
          ticket_id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          match_name?: string
          match_time?: string
          odds?: string
          prediction?: string
          ticket_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ticket_matches_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      ticket_packages: {
        Row: {
          created_at: string
          id: string
          package_id: string
          ticket_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          package_id: string
          ticket_id: string
        }
        Update: {
          created_at?: string
          id?: string
          package_id?: string
          ticket_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ticket_packages_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ticket_packages_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      tickets: {
        Row: {
          betika_link: string | null
          betpawa_link: string | null
          comments: string | null
          created_at: string
          created_by: string | null
          id: string
          image_url: string | null
          is_published: boolean
          match_count: number | null
          package_id: string | null
          published_at: string | null
          scheduled_at: string | null
          status: Database["public"]["Enums"]["ticket_status"]
          ticket_name: string
          updated_at: string
        }
        Insert: {
          betika_link?: string | null
          betpawa_link?: string | null
          comments?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          image_url?: string | null
          is_published?: boolean
          match_count?: number | null
          package_id?: string | null
          published_at?: string | null
          scheduled_at?: string | null
          status?: Database["public"]["Enums"]["ticket_status"]
          ticket_name?: string
          updated_at?: string
        }
        Update: {
          betika_link?: string | null
          betpawa_link?: string | null
          comments?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          image_url?: string | null
          is_published?: boolean
          match_count?: number | null
          package_id?: string | null
          published_at?: string | null
          scheduled_at?: string | null
          status?: Database["public"]["Enums"]["ticket_status"]
          ticket_name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tickets_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
        ]
      }
      tip_history: {
        Row: {
          action: string
          created_at: string
          created_by: string | null
          id: string
          new_status: string | null
          old_status: string | null
          ticket_id: string
        }
        Insert: {
          action: string
          created_at?: string
          created_by?: string | null
          id?: string
          new_status?: string | null
          old_status?: string | null
          ticket_id: string
        }
        Update: {
          action?: string
          created_at?: string
          created_by?: string | null
          id?: string
          new_status?: string | null
          old_status?: string | null
          ticket_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tip_history_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      user_devices: {
        Row: {
          browser_name: string | null
          browser_version: string | null
          created_at: string
          device_type: string | null
          id: string
          ip_address: unknown
          language: string | null
          os_name: string | null
          os_version: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          browser_name?: string | null
          browser_version?: string | null
          created_at?: string
          device_type?: string | null
          id?: string
          ip_address?: unknown
          language?: string | null
          os_name?: string | null
          os_version?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          browser_name?: string | null
          browser_version?: string | null
          created_at?: string
          device_type?: string | null
          id?: string
          ip_address?: unknown
          language?: string | null
          os_name?: string | null
          os_version?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_sessions: {
        Row: {
          browser_info: string | null
          created_at: string
          device_name: string | null
          id: string
          ip_address: unknown
          last_active: string
          operating_system: string | null
          user_id: string | null
        }
        Insert: {
          browser_info?: string | null
          created_at?: string
          device_name?: string | null
          id?: string
          ip_address?: unknown
          last_active?: string
          operating_system?: string | null
          user_id?: string | null
        }
        Update: {
          browser_info?: string | null
          created_at?: string
          device_name?: string | null
          id?: string
          ip_address?: unknown
          last_active?: string
          operating_system?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          created_at: string
          end_date: string
          id: string
          is_active: boolean | null
          package_id: string | null
          payment_method: string | null
          payment_reference: string | null
          start_date: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          end_date: string
          id?: string
          is_active?: boolean | null
          package_id?: string | null
          payment_method?: string | null
          payment_reference?: string | null
          start_date?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          end_date?: string
          id?: string
          is_active?: boolean | null
          package_id?: string | null
          payment_method?: string | null
          payment_reference?: string | null
          start_date?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_subscriptions_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "packages"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_expiring_subscriptions: { Args: never; Returns: undefined }
      cleanup_expired_free_tickets: { Args: never; Returns: undefined }
      cleanup_old_pending_transactions: { Args: never; Returns: undefined }
      cleanup_old_tickets: { Args: never; Returns: undefined }
      create_manual_subscription: {
        Args: {
          p_admin_id?: string
          p_duration_days: number
          p_package_id: string
          p_reason?: string
          p_user_id: string
        }
        Returns: string
      }
      extend_or_create_subscription: {
        Args: {
          p_duration_days: number
          p_package_id: string
          p_payment_reference: string
          p_user_id: string
        }
        Returns: string
      }
      extend_or_create_subscription_robust: {
        Args: {
          p_duration_days: number
          p_package_id: string
          p_payment_reference: string
          p_user_id: string
        }
        Returns: Json
      }
      extend_subscription_manual: {
        Args: {
          p_admin_id?: string
          p_days_to_add: number
          p_reason?: string
          p_subscription_id: string
          p_user_id: string
        }
        Returns: string
      }
      find_pesapal_transaction: {
        Args: { p_merchant_reference?: string; p_order_tracking_id: string }
        Returns: {
          amount_ugx: number
          created_at: string
          id: string
          merchant_reference: string
          order_tracking_id: string
          package_duration_days: number
          package_id: string
          package_name: string
          phone_number: string
          status: string
          user_id: string
        }[]
      }
      get_all_device_stats: {
        Args: never
        Returns: {
          desktop_users: number
          mobile_users: number
          tablet_users: number
          top_browser: string
          top_os: string
          total_devices: number
          total_users: number
        }[]
      }
      get_successful_revenue_by_package: {
        Args: { end_date?: string; start_date?: string }
        Returns: {
          package_id: string
          package_name: string
          total_revenue: number
          transaction_count: number
        }[]
      }
      get_transaction_package_info: {
        Args: { p_package_id: string }
        Returns: {
          duration_days: number
          name: string
        }[]
      }
      get_unmarked_tickets_count: { Args: never; Returns: number }
      get_user_device_stats: {
        Args: never
        Returns: {
          desktop_devices: number
          last_login: string
          mobile_devices: number
          tablet_devices: number
          total_devices: number
          unique_browsers: number
        }[]
      }
      has_recent_pending_payment: {
        Args: { p_package_id: string; p_user_id: string }
        Returns: boolean
      }
      increment_ad_impression: { Args: { p_ad_id: string }; Returns: undefined }
      is_admin: { Args: { user_id: string }; Returns: boolean }
      normalize_ug_phone: { Args: { phone: string }; Returns: string }
      publish_scheduled_tickets: { Args: never; Returns: number }
      track_ad_click: {
        Args: {
          p_ad_id: string
          p_ip_address?: unknown
          p_user_agent?: string
          p_user_id?: string
        }
        Returns: undefined
      }
      user_has_active_subscription: {
        Args: { p_user_id: string }
        Returns: boolean
      }
      user_has_package_access: {
        Args: { p_package_id: string; p_user_id: string }
        Returns: boolean
      }
      validate_ug_phone: { Args: { phone: string }; Returns: boolean }
    }
    Enums: {
      admin_role: "super_admin" | "admin" | "moderator"
      package_status: "active" | "paused"
      payment_status: "pending" | "approved" | "rejected"
      ticket_status: "pending" | "won" | "lost"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      admin_role: ["super_admin", "admin", "moderator"],
      package_status: ["active", "paused"],
      payment_status: ["pending", "approved", "rejected"],
      ticket_status: ["pending", "won", "lost"],
    },
  },
} as const
