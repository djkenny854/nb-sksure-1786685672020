/**
 * Detect if running inside a Capacitor native app
 */
export const isCapacitorNative = (): boolean => {
  return typeof (window as any).Capacitor !== 'undefined' 
    && (window as any).Capacitor.isNativePlatform();
};

export const getCurrentDomain = (): string => {
  // Check if we're in production
  if (window.location.hostname === 'skusers.vercel.app') {
    return 'https://skusers.vercel.app';
  }
  
  // Check for custom domain (you can add your custom domain here)
  const customDomains = [
    'skusers.vercel.app',
    // Add your custom domain here when you get one, e.g.:
    // 'yourdomainname.com',
    // 'www.yourdomainname.com'
  ];
  
  const currentHostname = window.location.hostname;
  
  // Check if current hostname is in our custom domains list
  if (customDomains.includes(currentHostname)) {
    return window.location.origin;
  }
  
  // For development and other environments
  if (currentHostname === 'localhost' || currentHostname.includes('lovableproject.com')) {
    return window.location.origin;
  }
  
  // Default fallback
  return 'https://skusers.vercel.app';
};

// Function to get the base domain for API callbacks
export const getCallbackDomain = (): string => {
  // For native apps, we still use the web URL for OAuth redirects
  // The deep link handler will catch these URLs and route them back to the app
  return 'https://skusers.vercel.app';
};

// Function to get the redirect URL for OAuth
export const getOAuthRedirectUrl = (): string => {
  // Always use the web URL - deep links will intercept and route back to app
  return 'https://skusers.vercel.app/auth';
};

// Function to get Pesapal callback URL
export const getPesapalCallbackUrl = (): string => {
  return 'https://skusers.vercel.app/pesapal-callback';
};

// Function to get Pesapal cancellation URL
export const getPesapalCancelUrl = (): string => {
  return 'https://skusers.vercel.app/payment-cancel';
};
