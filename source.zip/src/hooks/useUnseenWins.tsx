import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { hasAccess } from '@/lib/subscription';
import confetti from 'canvas-confetti';

const LAST_SEEN_WINS_KEY = 'sk_last_seen_wins_timestamp';
const UNSEEN_WIN_IDS_KEY = 'sk_unseen_win_ids';

export function useUnseenWins() {
  const { user } = useAuth();
  const [hasUnseenWins, setHasUnseenWins] = useState(false);
  const [unseenWinCount, setUnseenWinCount] = useState(0);

  // Trigger confetti celebration
  const triggerCelebration = useCallback((winCount: number = 1) => {
    // Fire confetti from both sides
    const duration = 3000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);

      // Confetti from left side
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        colors: ['#22c55e', '#16a34a', '#15803d', '#facc15', '#fbbf24'],
      });

      // Confetti from right side
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        colors: ['#22c55e', '#16a34a', '#15803d', '#facc15', '#fbbf24'],
      });
    }, 250);

    // Also trigger haptic feedback if available
    if ('vibrate' in navigator) {
      navigator.vibrate([100, 50, 100, 50, 200]);
    }
  }, []);

  // Check for unseen wins when user loads the app
  const checkUnseenWins = useCallback(async () => {
    if (!user) return;

    try {
      // Get last time user saw wins
      const lastSeenTimestamp = localStorage.getItem(LAST_SEEN_WINS_KEY);
      const unseenIdsStr = localStorage.getItem(UNSEEN_WIN_IDS_KEY);
      const previouslySeenIds = unseenIdsStr ? JSON.parse(unseenIdsStr) : [];

      // Get user's active subscriptions
      const { data: subscriptions } = await supabase
        .from('user_subscriptions')
        .select('package_id, start_date, end_date, is_active, packages(grace_period_days)')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .gte('end_date', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString());

      const accessibleSubs = (subscriptions || []).filter((s: any) => hasAccess(s));
      if (accessibleSubs.length === 0) return;

      const packageIds = accessibleSubs.map((sub: any) => sub.package_id);
      const earliestStart = accessibleSubs.reduce((earliest: string, sub: any) => 
        new Date(sub.start_date) < new Date(earliest) ? sub.start_date : earliest
      , accessibleSubs[0].start_date);

      // Query for won tickets since last seen
      let query = supabase
        .from('tickets')
        .select('id, ticket_name, updated_at')
        .in('package_id', packageIds)
        .gte('created_at', earliestStart)
        .eq('status', 'won');

      if (lastSeenTimestamp) {
        query = query.gt('updated_at', lastSeenTimestamp);
      }

      const { data: wonTickets } = await query;

      if (wonTickets && wonTickets.length > 0) {
        // Filter out previously seen wins
        const newWins = wonTickets.filter(t => !previouslySeenIds.includes(t.id));
        
        if (newWins.length > 0) {
          console.log(`🎉 Found ${newWins.length} unseen wins! Triggering celebration...`);
          setHasUnseenWins(true);
          setUnseenWinCount(newWins.length);
          
          // Trigger celebration
          triggerCelebration(newWins.length);
          
          // Mark these wins as seen
          const allSeenIds = [...previouslySeenIds, ...newWins.map(w => w.id)];
          localStorage.setItem(UNSEEN_WIN_IDS_KEY, JSON.stringify(allSeenIds));
          localStorage.setItem(LAST_SEEN_WINS_KEY, new Date().toISOString());
          
          // Reset state after celebration
          setTimeout(() => {
            setHasUnseenWins(false);
            setUnseenWinCount(0);
          }, 5000);
        }
      }
    } catch (error) {
      console.error('Error checking unseen wins:', error);
    }
  }, [user, triggerCelebration]);

  // Check on mount and when user changes
  useEffect(() => {
    if (user) {
      // Small delay to let the page load first
      const timer = setTimeout(() => {
        checkUnseenWins();
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [user, checkUnseenWins]);

  // Update last seen timestamp when user explicitly views tips
  const markWinsAsSeen = useCallback(() => {
    localStorage.setItem(LAST_SEEN_WINS_KEY, new Date().toISOString());
    setHasUnseenWins(false);
    setUnseenWinCount(0);
  }, []);

  return {
    hasUnseenWins,
    unseenWinCount,
    checkUnseenWins,
    markWinsAsSeen,
    triggerCelebration
  };
}
