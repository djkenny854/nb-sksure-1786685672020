import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { App } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';

/**
 * Hook to handle Android hardware back button in Capacitor apps.
 * Integrates with React Router to navigate back in history.
 * Only exits app when on root pages.
 */
export function useCapacitorBackButton() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Only run on native platforms
    if (!Capacitor.isNativePlatform()) {
      return;
    }

    const backButtonListener = App.addListener('backButton', ({ canGoBack }) => {
      const currentPath = location.pathname;
      
      // Root pages where we should exit the app
      const rootPages = ['/', '/app', '/auth', '/landing'];
      const isRootPage = rootPages.includes(currentPath);

      if (isRootPage) {
        // On root page, exit the app
        App.exitApp();
      } else if (canGoBack || window.history.length > 1) {
        // Navigate back in history
        navigate(-1);
      } else {
        // Fallback: go to home
        navigate('/app');
      }
    });

    // Cleanup listener on unmount
    return () => {
      backButtonListener.then(listener => listener.remove());
    };
  }, [navigate, location.pathname]);
}
