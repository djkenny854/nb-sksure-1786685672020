import { useEffect } from 'react';
import { useTheme } from 'next-themes';

/**
 * Keeps the browser/PWA status bar color in sync with the app background
 * so the installed app looks edge-to-edge in both light and dark mode.
 */
export function useThemeColorMeta() {
  const { resolvedTheme } = useTheme();

  useEffect(() => {
    const color = resolvedTheme === 'dark' ? '#000000' : '#ffffff';

    document
      .querySelectorAll('meta[name="theme-color"]')
      .forEach((el) => el.parentElement?.removeChild(el));

    const meta = document.createElement('meta');
    meta.name = 'theme-color';
    meta.content = color;
    document.head.appendChild(meta);

    let statusBar = document.querySelector(
      'meta[name="apple-mobile-web-app-status-bar-style"]',
    ) as HTMLMetaElement | null;
    if (!statusBar) {
      statusBar = document.createElement('meta');
      statusBar.name = 'apple-mobile-web-app-status-bar-style';
      document.head.appendChild(statusBar);
    }
    statusBar.content = 'black-translucent';

    document.documentElement.style.backgroundColor = color;
    document.body.style.backgroundColor = color;
  }, [resolvedTheme]);
}
