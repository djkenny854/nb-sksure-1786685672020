import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

const todayKey = () => `tipsViewed:${new Date().toISOString().slice(0, 10)}`;

export function useNewTipsIndicator() {
  const { user } = useAuth();
  const [newTipsCount, setNewTipsCount] = useState(0);
  const [viewedToday, setViewedToday] = useState<boolean>(() => localStorage.getItem(todayKey()) === '1');

  const fetchTodayCount = useCallback(async () => {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const { count, error } = await supabase
      .from('tickets')
      .select('id', { count: 'exact', head: true })
      .gte('created_at', startOfDay.toISOString());
    if (!error) setNewTipsCount(count || 0);
  }, []);

  useEffect(() => {
    if (!user) return;
    fetchTodayCount();

    const channel = supabase
      .channel(`new-tips-indicator-${user.id}-${Math.random().toString(36).slice(2)}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'tickets' }, () => {
        // A fresh ticket arrived today — show the badge again.
        localStorage.removeItem(todayKey());
        setViewedToday(false);
        fetchTodayCount();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, fetchTodayCount]);

  const markTipsAsViewed = useCallback(() => {
    localStorage.setItem(todayKey(), '1');
    setViewedToday(true);
  }, []);

  const badgeCount = viewedToday ? 0 : newTipsCount;

  return {
    hasNewTips: badgeCount > 0,
    newTipsCount: badgeCount,
    markTipsAsViewed,
  };
}
