import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface PackageStat {
  packageId: string;
  packageName: string;
  winStreak: number;
  totalWins: number;
  totalTips: number;
  accuracy: number;
  recentWins: number;
}

export function usePackageStats() {
  const [packageStats, setPackageStats] = useState<PackageStat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPackageStats();
  }, []);

  const fetchPackageStats = async () => {
    try {
      // Get all packages
      const { data: packages, error: packagesError } = await supabase
        .from('packages')
        .select('id, name')
        .eq('status', 'active');

      if (packagesError) throw packagesError;

      // Get tickets for each package
      const stats: PackageStat[] = [];

      for (const pkg of packages || []) {
        const { data: tickets, error: ticketsError } = await supabase
          .from('tickets')
          .select('id, status, created_at')
          .eq('package_id', pkg.id)
          .order('created_at', { ascending: false });

        if (ticketsError) continue;

        const wonTickets = tickets?.filter(t => t.status === 'won') || [];
        const lostTickets = tickets?.filter(t => t.status === 'lost') || [];
        const totalCompleted = wonTickets.length + lostTickets.length;
        const accuracy = totalCompleted > 0 ? (wonTickets.length / totalCompleted) * 100 : 0;

        // Calculate current win streak
        let winStreak = 0;
        const completedTickets = tickets?.filter(t => t.status === 'won' || t.status === 'lost') || [];
        for (const ticket of completedTickets) {
          if (ticket.status === 'won') {
            winStreak++;
          } else {
            break;
          }
        }

        // Count recent wins (last 7 days)
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        const recentWins = wonTickets.filter(t => 
          new Date(t.created_at) >= sevenDaysAgo
        ).length;

        stats.push({
          packageId: pkg.id,
          packageName: pkg.name,
          winStreak,
          totalWins: wonTickets.length,
          totalTips: tickets?.length || 0,
          accuracy,
          recentWins
        });
      }

      // Sort by win streak descending
      stats.sort((a, b) => b.winStreak - a.winStreak);
      setPackageStats(stats);
    } catch (error) {
      console.error('Error fetching package stats:', error);
    } finally {
      setLoading(false);
    }
  };

  return { packageStats, loading, refetch: fetchPackageStats };
}
