
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface Notification {
  id: string;
  user_id: string | null;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  is_read: boolean;
  created_at: string;
  is_broadcast: boolean;
  is_system_generated: boolean;
}

export function useNotifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [processedNotifications, setProcessedNotifications] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!user) return;
    fetchNotifications();
    const cleanup = setupRealtimeSubscription();
    return cleanup;
  }, [user]);

  const fetchNotifications = async () => {
    if (!user) return;

    try {
      console.log('📋 Fetching notifications for user:', user.id);
      
      const { data, error } = await supabase
        .from('notifications')
        .select('id, user_id, title, message, type, is_read, created_at, updated_at, is_system_generated')
        .or(`user_id.eq.${user.id},user_id.is.null`)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('❌ Error fetching notifications:', error);
        setNotifications([]);
        setUnreadCount(0);
      } else {
        console.log('📋 Notifications fetched:', data);
        
        // Remove duplicates based on title and message combination
        const uniqueNotifications = (data || []).filter((notification, index, self) => 
          index === self.findIndex(n => 
            n.title === notification.title && 
            n.message === notification.message &&
            n.user_id === notification.user_id
          )
        );

        const notificationsData: Notification[] = uniqueNotifications.map(notification => ({
          id: notification.id,
          user_id: notification.user_id,
          title: notification.title,
          message: notification.message,
          type: notification.type as 'info' | 'warning' | 'success' | 'error',
          is_read: notification.is_read,
          created_at: notification.created_at,
          is_broadcast: notification.user_id === null,
          is_system_generated: notification.is_system_generated
        }));

        setNotifications(notificationsData);
        setUnreadCount(notificationsData.filter(n => !n.is_read).length);
      }
    } catch (error) {
      console.error('💥 Error fetching notifications:', error);
      setNotifications([]);
      setUnreadCount(0);
    }
    setLoading(false);
  };

  const setupRealtimeSubscription = () => {
    if (!user) return;

    console.log('🔔 Setting up realtime subscription for notifications');
    
    const channel = supabase
      .channel(`notifications-realtime-${user.id}-${Math.random().toString(36).slice(2)}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notifications'
        },
        (payload) => {
          console.log('🔔 Notification realtime event:', payload);
          
          // Prevent processing duplicate notifications
          if (payload.eventType === 'INSERT' && payload.new) {
            const newNotification = payload.new as any;
            const notificationKey = `${newNotification.title}-${newNotification.message}-${newNotification.user_id}`;
            
            if (!processedNotifications.has(notificationKey)) {
              setProcessedNotifications(prev => new Set(prev).add(notificationKey));
              fetchNotifications();
            }
          } else {
            fetchNotifications();
          }
        }
      )
      .subscribe();

    return () => {
      console.log('🔔 Cleaning up notification subscription');
      supabase.removeChannel(channel);
    };
  };

  const markAsRead = async (notificationId: string) => {
    try {
      console.log('✅ Marking notification as read:', notificationId);
      
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true, updated_at: new Date().toISOString() })
        .eq('id', notificationId);

      if (!error) {
        setNotifications(prev => prev.filter(n => n.id !== notificationId));
        setUnreadCount(prev => Math.max(0, prev - 1));
      } else {
        console.error('❌ Error marking notification as read:', error);
      }
    } catch (error) {
      console.error('💥 Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    if (!user) return;

    try {
      console.log('✅ Marking all notifications as read for user:', user.id);
      
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true, updated_at: new Date().toISOString() })
        .or(`user_id.eq.${user.id},user_id.is.null`)
        .eq('is_read', false);

      if (!error) {
        setNotifications([]);
        setUnreadCount(0);
      } else {
        console.error('❌ Error marking all notifications as read:', error);
      }
    } catch (error) {
      console.error('💥 Error marking all notifications as read:', error);
    }
  };

  return {
    notifications,
    unreadCount,
    loading,
    markAsRead,
    markAllAsRead,
    refetch: fetchNotifications
  };
}
