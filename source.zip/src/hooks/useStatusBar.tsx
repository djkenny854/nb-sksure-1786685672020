import { useEffect } from 'react';
import { useTheme } from 'next-themes';
import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';

/**
 * Hook to configure the native status bar based on the app theme.
 * Handles status bar style (light/dark) and background color.
 */
export function useStatusBar() {
  const { theme, resolvedTheme } = useTheme();

  useEffect(() => {
    // Only run on native platforms
    if (!Capacitor.isNativePlatform()) {
      return;
    }

    const configureStatusBar = async () => {
      try {
        const isDark = resolvedTheme === 'dark' || theme === 'dark';

        // Set status bar style based on theme
        // Light style = white text (for dark backgrounds)
        // Dark style = black text (for light backgrounds)
        await StatusBar.setStyle({
          style: isDark ? Style.Dark : Style.Light
        });

        // Set status bar background color
        await StatusBar.setBackgroundColor({
          color: isDark ? '#000000' : '#ffffff'
        });

        // Make status bar overlay the content
        await StatusBar.setOverlaysWebView({ overlay: true });

        console.log('Status bar configured for', isDark ? 'dark' : 'light', 'theme');
      } catch (error) {
        console.error('Error configuring status bar:', error);
      }
    };

    configureStatusBar();
  }, [theme, resolvedTheme]);
}
