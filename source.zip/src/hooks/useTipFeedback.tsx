import { useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

// Sound effect URL - short success chime
const WIN_SOUND_URL = 'https://cdn.freesound.org/previews/341/341695_5858296-lq.mp3';

export function useTipFeedback() {
  const { user } = useAuth();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const previousWonIdsRef = useRef<Set<string>>(new Set());
  const isInitializedRef = useRef(false);

  // Initialize audio element
  useEffect(() => {
    audioRef.current = new Audio(WIN_SOUND_URL);
    audioRef.current.volume = 0.5;
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  // Trigger haptic feedback
  const triggerHaptic = () => {
    if ('vibrate' in navigator) {
      // Success pattern: two short vibrations
      navigator.vibrate([100, 50, 100]);
    }
  };

  // Play win sound
  const playWinSound = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(err => {
        console.log('Audio play failed (user interaction required):', err);
      });
    }
  };

  // Combined feedback
  const triggerWinFeedback = () => {
    playWinSound();
    triggerHaptic();
  };

  // Listen for ticket status changes
  useEffect(() => {
    if (!user) return;

    // First, fetch initial won tickets to avoid false triggers on page load
    const initializeWonTickets = async () => {
      const { data } = await supabase
        .from('tickets')
        .select('id')
        .eq('status', 'won');
      
      if (data) {
        data.forEach(ticket => previousWonIdsRef.current.add(ticket.id));
      }
      isInitializedRef.current = true;
    };

    initializeWonTickets();

    // Subscribe to realtime updates
    const channel = supabase
      .channel('tip-feedback-channel')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'tickets',
          filter: 'status=eq.won'
        },
        (payload) => {
          if (!isInitializedRef.current) return;
          
          const ticketId = payload.new.id;
          const oldStatus = payload.old?.status;
          
          // Only trigger if this is a NEW win (not already in our set)
          if (!previousWonIdsRef.current.has(ticketId) && oldStatus !== 'won') {
            console.log('🎉 New win detected! Triggering feedback...');
            previousWonIdsRef.current.add(ticketId);
            triggerWinFeedback();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  return {
    triggerWinFeedback,
    playWinSound,
    triggerHaptic
  };
}
