import { useState, useEffect } from 'react';
import { Capacitor } from '@capacitor/core';

/**
 * Hook to detect if the app is running in a Capacitor native environment
 * 
 * This automatically detects whether we're running as:
 * - A native Android/iOS app (returns true)
 * - A web browser (returns false)
 * 
 * Use this to conditionally show/hide features that only make sense
 * in one environment or the other (e.g., hide "Download App" in native)
 */
export function useCapacitorDetection() {
  const [isNative, setIsNative] = useState(false);
  const [platform, setPlatform] = useState<'web' | 'android' | 'ios'>('web');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Check if Capacitor is available and we're on a native platform
    const checkPlatform = () => {
      try {
        const native = Capacitor.isNativePlatform();
        const currentPlatform = Capacitor.getPlatform() as 'web' | 'android' | 'ios';
        
        setIsNative(native);
        setPlatform(currentPlatform);
        setIsReady(true);
        
        console.log(`[Capacitor] Platform: ${currentPlatform}, Native: ${native}`);
      } catch (error) {
        // Capacitor not available - we're on web
        setIsNative(false);
        setPlatform('web');
        setIsReady(true);
        console.log('[Capacitor] Not available - running on web');
      }
    };

    checkPlatform();
  }, []);

  return {
    isNative,
    platform,
    isReady,
    isAndroid: platform === 'android',
    isIOS: platform === 'ios',
    isWeb: platform === 'web',
  };
}

/**
 * Simple function to check if we're in a native environment
 * Use this for non-hook contexts
 */
export function isCapacitorNative(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/**
 * Get the current platform
 */
export function getCapacitorPlatform(): 'web' | 'android' | 'ios' {
  try {
    return Capacitor.getPlatform() as 'web' | 'android' | 'ios';
  } catch {
    return 'web';
  }
}
