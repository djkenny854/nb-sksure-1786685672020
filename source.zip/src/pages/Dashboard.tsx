import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { SubscriptionProgress } from '@/components/SubscriptionProgress'
import { PageTransition } from '@/components/PageTransition'
import { TopHeader } from '@/components/TopHeader'
import { TrendingUp, Target, Trophy, CheckCircle2, ChevronRight, History, MoreHorizontal, Sparkles } from 'lucide-react'
import { 
  Area, 
  AreaChart, 
  ResponsiveContainer,
  XAxis, 
  YAxis, 
  Tooltip
} from 'recharts'
import { useAuth } from '@/hooks/useAuth'
import { useTickets } from '@/hooks/useTickets'
import { useSubscriptions } from '@/hooks/useSubscriptions'
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Dashboard() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const { tickets } = useTickets()
  const { subscriptions } = useSubscriptions()
  const [stats, setStats] = useState({
    weeklyAccuracy: 0,
    totalTips: 0,
    winStreak: 0,
    wonTips: 0,
    lostTips: 0,
    pendingTips: 0
  })

  // Calculate real stats from tickets
  useEffect(() => {
    if (tickets.length > 0) {
      const wonTickets = tickets.filter(t => t.status === 'won').length
      const lostTickets = tickets.filter(t => t.status === 'lost').length
      const pendingTickets = tickets.filter(t => t.status === 'pending').length
      const totalCompleted = wonTickets + lostTickets
      const accuracy = totalCompleted > 0 ? (wonTickets / totalCompleted) * 100 : 0
      
      // Calculate win streak
      let streak = 0
      for (let i = tickets.length - 1; i >= 0; i--) {
        if (tickets[i].status === 'won') {
          streak++
        } else if (tickets[i].status === 'lost') {
          break
        }
      }

      setStats({
        weeklyAccuracy: accuracy,
        totalTips: tickets.length,
        winStreak: streak,
        wonTips: wonTickets,
        lostTips: lostTickets,
        pendingTips: pendingTickets
      })
    }
  }, [tickets])

  // Generate weekly performance data from real tickets
  const getWeeklyPerformance = () => {
    const today = new Date()
    const weekData = []
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)
      const dayName = date.toLocaleDateString('en', { weekday: 'short' })
      
      const dayTickets = tickets.filter(ticket => {
        const ticketDate = new Date(ticket.created_at)
        return ticketDate.toDateString() === date.toDateString()
      })
      
      const dayWins = dayTickets.filter(t => t.status === 'won').length
      const dayLosses = dayTickets.filter(t => t.status === 'lost').length
      const dayAccuracy = dayWins + dayLosses > 0 ? (dayWins / (dayWins + dayLosses)) * 100 : 0
      
      weekData.push({
        day: dayName,
        wins: dayWins,
        losses: dayLosses,
        accuracy: dayAccuracy
      })
    }
    
    return weekData
  }

  const weeklyPerformance = getWeeklyPerformance()

  return (
    <PageTransition>
    <div className="min-h-screen bg-background">
      {/* Top Header */}
      <TopHeader />

      {/* Content */}
      <div className="divide-y divide-border">
        {/* Welcome Card */}
        <div className="p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <Target className="w-5 h-5 text-primary-foreground" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-bold text-[15px] text-foreground">Kalaso Football Predictions</span>
                <Badge className="bg-primary text-primary-foreground text-[11px] px-1.5 py-0 h-5 rounded">Premium</Badge>
              </div>
              <p className="text-[15px] text-foreground mt-1">
                Welcome back, {user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Champion'}! 🎯
              </p>
              <p className="text-[15px] text-muted-foreground mt-1">
                Your current win rate is {stats.weeklyAccuracy.toFixed(1)}% with {stats.totalTips} total tips.
              </p>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="p-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-4 bg-muted/50 rounded-2xl">
              <div className="text-2xl font-bold text-green-500">{stats.wonTips}</div>
              <div className="text-[13px] text-muted-foreground mt-1">Won</div>
            </div>
            <div className="text-center p-4 bg-muted/50 rounded-2xl">
              <div className="text-2xl font-bold text-destructive">{stats.lostTips}</div>
              <div className="text-[13px] text-muted-foreground mt-1">Lost</div>
            </div>
            <div className="text-center p-4 bg-muted/50 rounded-2xl">
              <div className="text-2xl font-bold text-primary">{stats.pendingTips}</div>
              <div className="text-[13px] text-muted-foreground mt-1">Pending</div>
            </div>
          </div>
        </div>

        {/* Active Subscriptions */}
        {subscriptions.length > 0 && (
          <div className="p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="font-bold text-[15px] text-foreground">Active Packages</span>
              <button 
                onClick={() => navigate('/app/packages')}
                className="text-primary text-[15px] hover:underline"
              >
                View all
              </button>
            </div>
            <Card className="bg-muted/30 border-0 rounded-2xl">
              <CardContent className="p-4">
                <SubscriptionProgress />
              </CardContent>
            </Card>
          </div>
        )}

        {/* Performance Stats List */}
        <div className="p-4">
          <h2 className="font-bold text-[15px] text-foreground mb-3">Performance Overview</h2>
          
          {/* Weekly Accuracy */}
          <button 
            className="w-full flex items-center justify-between py-3 hover:bg-muted/50 transition-colors rounded-xl px-2 -mx-2"
            onClick={() => navigate('/app/tips')}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <div className="text-left">
                <div className="font-medium text-[15px] text-foreground">Weekly Accuracy</div>
                <div className="text-[13px] text-muted-foreground">Based on completed tips</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-green-500/10 text-green-500 border-0 font-bold">
                {stats.weeklyAccuracy.toFixed(1)}%
              </Badge>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </button>

          {/* Win Streak */}
          <button 
            className="w-full flex items-center justify-between py-3 hover:bg-muted/50 transition-colors rounded-xl px-2 -mx-2"
            onClick={() => navigate('/app/tips')}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-yellow-500/10 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-yellow-500" />
              </div>
              <div className="text-left">
                <div className="font-medium text-[15px] text-foreground">Win Streak</div>
                <div className="text-[13px] text-muted-foreground">Consecutive wins</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-yellow-500/10 text-yellow-500 border-0 font-bold">
                {stats.winStreak} wins
              </Badge>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </button>

          {/* Total Tips */}
          <button 
            className="w-full flex items-center justify-between py-3 hover:bg-muted/50 transition-colors rounded-xl px-2 -mx-2"
            onClick={() => navigate('/app/tips')}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <History className="w-5 h-5 text-primary" />
              </div>
              <div className="text-left">
                <div className="font-medium text-[15px] text-foreground">Total Tips</div>
                <div className="text-[13px] text-muted-foreground">All time</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-primary/10 text-primary border-0 font-bold">
                {stats.totalTips}
              </Badge>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </button>
        </div>

        {/* Weekly Chart */}
        <div className="p-4">
          <h2 className="font-bold text-[15px] text-foreground mb-3">Weekly Performance</h2>
          <Card className="bg-muted/30 border-0 rounded-2xl">
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={weeklyPerformance}>
                  <XAxis 
                    dataKey="day" 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip 
                    formatter={(value) => [`${value}%`, 'Accuracy']}
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--popover))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '12px',
                      fontSize: '14px'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="accuracy" 
                    stroke="hsl(var(--primary))" 
                    fill="hsl(var(--primary))" 
                    fillOpacity={0.1}
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="p-4 pb-8">
          <h2 className="font-bold text-[15px] text-foreground mb-3">Quick Actions</h2>
          <div className="flex flex-wrap gap-2">
            <button 
              onClick={() => navigate('/app/tips')}
              className="px-4 py-2 bg-muted/50 hover:bg-muted rounded-full text-[15px] font-medium text-foreground transition-colors"
            >
              View Tips
            </button>
            <button 
              onClick={() => navigate('/app/packages')}
              className="px-4 py-2 bg-muted/50 hover:bg-muted rounded-full text-[15px] font-medium text-foreground transition-colors"
            >
              Packages
            </button>
            <button 
              onClick={() => navigate('/app/transactions')}
              className="px-4 py-2 bg-muted/50 hover:bg-muted rounded-full text-[15px] font-medium text-foreground transition-colors"
            >
              Transactions
            </button>
          </div>
        </div>
      </div>
    </div>
    </PageTransition>
  )
}
