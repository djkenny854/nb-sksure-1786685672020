
import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { toast } from '@/hooks/use-toast';
import { Eye, EyeOff, Lock, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function ResetPassword() {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isValidSession, setIsValidSession] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;

    const initializePasswordReset = async () => {
      try {
        console.log('Initializing password reset...');
        
        // Get all URL parameters
        const accessToken = searchParams.get('access_token');
        const refreshToken = searchParams.get('refresh_token');
        const type = searchParams.get('type');
        const error = searchParams.get('error');
        const errorDescription = searchParams.get('error_description');

        console.log('Reset password params:', { 
          hasAccessToken: !!accessToken, 
          hasRefreshToken: !!refreshToken, 
          type, 
          error, 
          errorDescription 
        });

        // Check for errors in URL first
        if (error) {
          console.error('Reset password error from URL:', error, errorDescription);
          toast({
            title: "Reset Link Error",
            description: errorDescription || "This password reset link is invalid or has expired.",
            variant: "destructive"
          });
          if (mounted) {
            navigate('/auth');
          }
          return;
        }

        // Check if we have the required tokens and type
        if (accessToken && refreshToken && type === 'recovery') {
          console.log('Setting session with tokens...');
          
          const { data, error: sessionError } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken
          });

          if (sessionError) {
            console.error('Session error:', sessionError);
            toast({
              title: "Invalid Reset Link",
              description: "This password reset link is invalid or has expired. Please request a new one.",
              variant: "destructive"
            });
            if (mounted) {
              navigate('/auth');
            }
            return;
          }

          if (data.session && data.user) {
            console.log('Session set successfully');
            if (mounted) {
              setIsValidSession(true);
              toast({
                title: "Ready to Reset",
                description: "You can now set your new password.",
              });
            }
          } else {
            console.error('No session or user data received');
            toast({
              title: "Session Error",
              description: "Unable to verify your reset link. Please try again.",
              variant: "destructive"
            });
            if (mounted) {
              navigate('/auth');
            }
          }
        } else {
          // Check if user is already authenticated (might have clicked link multiple times)
          const { data: { session } } = await supabase.auth.getSession();
          
          if (session && session.user) {
            console.log('User already has valid session');
            if (mounted) {
              setIsValidSession(true);
              toast({
                title: "Session Active",
                description: "You can now set your new password.",
              });
            }
          } else {
            console.log('No valid reset parameters or session found');
            toast({
              title: "Invalid Reset Link",
              description: "This password reset link is invalid or has expired. Please request a new one.",
              variant: "destructive"
            });
            if (mounted) {
              navigate('/auth');
            }
          }
        }
      } catch (error) {
        console.error('Error initializing password reset:', error);
        toast({
          title: "Reset Link Error",
          description: "There was an error processing your reset link.",
          variant: "destructive"
        });
        if (mounted) {
          navigate('/auth');
        }
      } finally {
        if (mounted) {
          setIsInitializing(false);
        }
      }
    };

    initializePasswordReset();

    return () => {
      mounted = false;
    };
  }, [searchParams, navigate]);

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isValidSession) {
      toast({
        title: "Session Expired",
        description: "Please request a new password reset link.",
        variant: "destructive"
      });
      navigate('/auth');
      return;
    }

    if (password !== confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "The passwords you entered do not match.",
        variant: "destructive"
      });
      return;
    }

    if (password.length < 6) {
      toast({
        title: "Password Too Short",
        description: "Password must be at least 6 characters long.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    try {
      console.log('Updating user password...');
      
      const { error } = await supabase.auth.updateUser({
        password: password
      });

      if (error) {
        console.error('Password update error:', error);
        toast({
          title: "Reset Failed",
          description: error.message || "Failed to reset password. Please try again.",
          variant: "destructive"
        });
        return;
      }

      console.log('Password updated successfully');
      toast({
        title: "Password Reset Successful! 🎉",
        description: "Your password has been updated successfully. You can now sign in with your new password.",
      });

      // Sign out the user and redirect to login after a short delay
      setTimeout(async () => {
        await supabase.auth.signOut();
        navigate('/auth');
      }, 2000);

    } catch (error: any) {
      console.error('Password reset catch error:', error);
      toast({
        title: "Reset Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (isInitializing || !isValidSession) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <LoadingSpinner size="lg" variant="google" className="mb-4" />
          <p className="text-muted-foreground">
            {isInitializing ? 'Verifying reset link...' : 'Redirecting...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-background border-b border-border px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link to="/auth" className="flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Sign In</span>
          </Link>
          <div className="flex items-center space-x-3">
            <img 
              src="/icons/icon-192.png" 
              alt="Kalaso Football Predictions Logo" 
              className="w-16 h-16 object-contain"
            />
            <span className="text-lg font-semibold text-foreground">Kalaso Football Predictions</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex min-h-[calc(100vh-80px)] items-center justify-center p-8">
        <div className="w-full max-w-md">
          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center pb-8">
              <div className="flex items-center justify-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                  <Lock className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <CardTitle className="text-2xl font-bold text-foreground">Reset Password</CardTitle>
                  <p className="text-sm text-muted-foreground">Enter your new password</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleResetPassword} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-base font-medium">New Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your new password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="h-12 text-base pr-12"
                      required
                      minLength={6}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-12 px-3"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirm-password" className="text-base font-medium">Confirm New Password</Label>
                  <div className="relative">
                    <Input
                      id="confirm-password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Confirm your new password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="h-12 text-base pr-12"
                      required
                      minLength={6}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-12 px-3"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </Button>
                  </div>
                </div>

                {password && confirmPassword && password !== confirmPassword && (
                  <p className="text-sm text-destructive">Passwords do not match</p>
                )}

                <Button 
                  type="submit" 
                  className="w-full h-12 text-base font-semibold" 
                  disabled={loading || !password || !confirmPassword || password !== confirmPassword}
                >
                  {loading ? "Updating Password..." : "Update Password"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
