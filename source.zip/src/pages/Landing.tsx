import { useAuth } from '@/hooks/useAuth';
import { useCapacitorDetection } from '@/hooks/useCapacitorDetection';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Button } from '@/components/ui/button';
import { Trophy, Shield, TrendingUp, Users, Star, ArrowRight, Phone, Mail, MapPin, Menu, X, MessageCircle, Facebook, Instagram, Download } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { FeaturedPackages } from '@/components/FeaturedPackages';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { GetAppModal } from '@/components/GetAppModal';

export default function Landing() {
  const { user, loading } = useAuth();
  const { isNative } = useCapacitorDetection();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [navVisible, setNavVisible] = useState(true);
  const [getAppModalOpen, setGetAppModalOpen] = useState(false);

  // Social media links - you can update these later
  const socialLinks = {
    whatsapp: 'https://wa.me/256700123456',
    tiktok: 'https://tiktok.com/@sksurewins',
    gmail: 'mailto:support@sksurewins.com',
    facebook: 'https://facebook.com/sksurewins',
    instagram: 'https://instagram.com/sksurewins',
    phone: 'tel:+256700123456'
  };

  const handleSocialClick = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      // Update scrolled state for blur effect
      setScrolled(currentScrollY > 50);

      // Handle navbar visibility
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        // Scrolling down - hide navbar
        setNavVisible(false);
      } else {
        // Scrolling up - show navbar
        setNavVisible(true);
      }
      setLastScrollY(currentScrollY);
    };
    window.addEventListener('scroll', handleScroll, {
      passive: true
    });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  if (loading) {
    return <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <LoadingSpinner size="lg" variant="google" className="mb-4" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>;
  }

  return <div className="min-h-screen bg-white font-['Poppins',sans-serif]">
      {/* Modern Header with Blur */}
      <header className={`
        fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out
        ${navVisible ? 'translate-y-0' : '-translate-y-full'}
        ${scrolled ? 'bg-white/80 backdrop-blur-md border-b border-gray-200/50 shadow-lg' : 'bg-transparent'}
      `}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center px-0 py-0 my-0">
            <div className="flex items-center space-x-3 animate-fade-in">
              <img src="/lovable-uploads/7799326b-6128-47df-9e48-b1abdc4cb85d.png" alt="Kalaso Football Predictions Logo" className="w-15 h-15 object-contain hover:scale-110 transition-transform duration-300" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 font-heading"></h1>
                <p className="text-sm text-gray-600"></p>
              </div>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-6">
              <Link to="/plans" className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition-all duration-300 hover:scale-105 group">
                <Trophy className="w-4 h-4 group-hover:rotate-12 transition-transform duration-300" />
                <span className="font-medium">Packages</span>
              </Link>
              <Link to="/free-tips" className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition-all duration-300 hover:scale-105 group">
                <Star className="w-4 h-4 group-hover:rotate-12 transition-transform duration-300" />
                <span className="font-medium">Free Tips</span>
              </Link>
              <Link to="/contact" className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition-all duration-300 hover:scale-105 group">
                <Phone className="w-4 h-4 group-hover:rotate-12 transition-transform duration-300" />
                <span className="font-medium">Contact</span>
              </Link>
              {/* Hide Get App button in native Capacitor environment */}
              {!isNative && (
                <button
                  onClick={() => setGetAppModalOpen(true)}
                  className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 transition-all duration-300 hover:scale-105 group"
                >
                  <Download className="w-4 h-4 group-hover:rotate-12 transition-transform duration-300" />
                  <span className="font-medium">Get App</span>
                </button>
              )}
              {user ? <Link to="/app">
                  <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-2 rounded-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                    Dashboard
                  </Button>
                </Link> : <Link to="/auth">
                  <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-2 rounded-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                    Sign In
                  </Button>
                </Link>}
            </nav>

            {/* Mobile menu button */}
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Modal */}
      <Dialog open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <DialogContent className="sm:max-w-md mx-auto font-['Poppins',sans-serif] bg-white border-none shadow-2xl">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="text-xl font-semibold text-gray-900">
                Menu
              </DialogTitle>
              <Button variant="ghost" size="sm" onClick={() => setMobileMenuOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            {/* Navigation Links */}
            <div className="space-y-2">
              <Link to="/plans" className="flex items-center space-x-3 text-gray-700 hover:text-blue-600 transition-colors py-3 px-2 rounded-lg hover:bg-gray-50" onClick={() => setMobileMenuOpen(false)}>
                <Trophy className="w-5 h-5" />
                <span className="font-medium">Packages</span>
              </Link>
              <Link to="/free-tips" className="flex items-center space-x-3 text-gray-700 hover:text-blue-600 transition-colors py-3 px-2 rounded-lg hover:bg-gray-50" onClick={() => setMobileMenuOpen(false)}>
                <Star className="w-5 h-5" />
                <span className="font-medium">Free Tips</span>
              </Link>
              <Link to="/contact" className="flex items-center space-x-3 text-gray-700 hover:text-blue-600 transition-colors py-3 px-2 rounded-lg hover:bg-gray-50" onClick={() => setMobileMenuOpen(false)}>
                <Phone className="w-5 h-5" />
                <span className="font-medium">Contact</span>
              </Link>
              {/* Hide Get App button in native Capacitor environment */}
              {!isNative && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setGetAppModalOpen(true);
                  }}
                  className="flex items-center space-x-3 text-gray-700 hover:text-blue-600 transition-colors py-3 px-2 rounded-lg hover:bg-gray-50 w-full text-left"
                >
                  <Download className="w-5 h-5" />
                  <span className="font-medium">Get App</span>
                </button>
              )}
            </div>

            {/* Social Media Links */}
            <div className="border-t pt-4">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">Connect with us</h3>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2 justify-start"
                  onClick={() => handleSocialClick(socialLinks.whatsapp)}
                >
                  <MessageCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">WhatsApp</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2 justify-start"
                  onClick={() => handleSocialClick(socialLinks.phone)}
                >
                  <Phone className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">Call</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2 justify-start"
                  onClick={() => handleSocialClick(socialLinks.gmail)}
                >
                  <Mail className="h-4 w-4 text-red-600" />
                  <span className="text-sm">Gmail</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2 justify-start"
                  onClick={() => handleSocialClick(socialLinks.facebook)}
                >
                  <Facebook className="h-4 w-4 text-blue-800" />
                  <span className="text-sm">Facebook</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2 justify-start"
                  onClick={() => handleSocialClick(socialLinks.instagram)}
                >
                  <Instagram className="h-4 w-4 text-pink-600" />
                  <span className="text-sm">Instagram</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2 justify-start"
                  onClick={() => handleSocialClick(socialLinks.tiktok)}
                >
                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19.321 5.562a5.124 5.124 0 01-.443-.258 6.228 6.228 0 01-1.137-.966c-.849-.849-1.204-1.924-1.204-2.338v-.001C16.537 1.999 16.538 2 16.538 2h-3.685v12.8c0 2.278-1.844 4.127-4.127 4.127s-4.127-1.849-4.127-4.127 1.849-4.127 4.127-4.127c.284 0 .56.029.825.082V7.187c-.27-.041-.548-.062-.825-.062C4.785 7.125 1.8 10.11 1.8 13.751S4.785 20.377 8.426 20.377s6.626-2.985 6.626-6.626V8.987a9.483 9.483 0 004.969 1.37v-3.624c0-.001-.533.044-1.7-.171z"/>
                  </svg>
                  <span className="text-sm">TikTok</span>
                </Button>
              </div>
            </div>

            {/* Auth Button */}
            <div className="border-t pt-4">
              {user ? <Link to="/app" onClick={() => setMobileMenuOpen(false)}>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-2 rounded-lg font-semibold">
                    Dashboard
                  </Button>
                </Link> : <Link to="/auth" onClick={() => setMobileMenuOpen(false)}>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-2 rounded-lg font-semibold">
                    Sign In
                  </Button>
                </Link>}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Hero Section with Modern Design and Improved Mobile Spacing */}
      <section className="relative min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center pt-28 md:pt-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="animate-fade-in-up space-y-8">
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 bg-clip-text text-transparent py-[21px]">
                Win Big with Professional Football Predictions
              </h2>
              <p className="text-lg sm:text-xl text-gray-600 leading-relaxed">
                Join thousands of successful bettors who trust Kalaso Football Predictions for accurate football predictions, expert analysis, and winning strategies.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/plans">
                  <Button className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                    View Packages
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to="/free-tips">
                  <Button variant="outline" className="w-full sm:w-auto border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 hover:scale-105">
                    Free Tips
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="relative lg:pl-12 mt-8 lg:mt-0">
              <div className="relative z-10 animate-fade-in" style={{
              animationDelay: '0.3s'
            }}>
                <img src="/lovable-uploads/07bba944-8a03-4933-9b65-3a058dd358d9.png" alt="Kalaso Football Predictions Professional" className="w-full max-w-2xl mx-auto h-auto object-contain animate-float drop-shadow-2xl" />
              </div>
              
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 w-72 h-72 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-br from-purple-400/20 to-pink-400/20 rounded-full blur-2xl animate-pulse" style={{
              animationDelay: '1s'
            }}></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-r from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-bold text-blue-600 mb-2 group-hover:scale-110 transition-transform duration-300">5000+</div>
              <div className="text-gray-600 font-medium">Active Users</div>
            </div>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-bold text-green-600 mb-2 group-hover:scale-110 transition-transform duration-300">85%</div>
              <div className="text-gray-600 font-medium">Success Rate</div>
            </div>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-bold text-purple-600 mb-2 group-hover:scale-110 transition-transform duration-300">150+</div>
              <div className="text-gray-600 font-medium">Leagues Covered</div>
            </div>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="text-4xl font-bold text-orange-600 mb-2 group-hover:scale-110 transition-transform duration-300">24/7</div>
              <div className="text-gray-600 font-medium">Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-4xl font-bold text-gray-900 mb-4 font-heading">Why Choose Kalaso Football Predictions?</h2>
            <p className="text-xl text-gray-600">Experience the difference with our premium football prediction service</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100 hover:border-blue-200 group hover:-translate-y-2">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Trophy className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 font-heading">Expert Analysis</h3>
              <p className="text-gray-600 leading-relaxed">
                Our team of professional analysts provides in-depth match analysis and predictions based on comprehensive data and statistics.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100 hover:border-green-200 group hover:-translate-y-2">
              <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-green-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Shield className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 font-heading">Proven Track Record</h3>
              <p className="text-gray-600 leading-relaxed">
                With an 85% success rate and thousands of satisfied customers, we have established ourselves as a trusted prediction service.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100 hover:border-purple-200 group hover:-translate-y-2">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-purple-200 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 font-heading">Daily Updates</h3>
              <p className="text-gray-600 leading-relaxed">
                Get fresh predictions daily covering major leagues worldwide, ensuring you never miss a profitable opportunity.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Packages Section - Dynamic from Supabase */}
      <FeaturedPackages />

      {/* Testimonials Section */}
      <section className="py-20 bg-gradient-to-r from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-4xl font-bold text-gray-900 mb-4 font-heading">What Our Customers Say</h2>
            <p className="text-xl text-gray-600">Join thousands of satisfied customers who trust Kalaso Football Predictions</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
              <div className="flex items-center mb-6">
                <div className="flex text-blue-500">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-current" />)}
                </div>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                "Kalaso Football Predictions has completely changed my betting game. Their predictions are incredibly accurate and have helped me win consistently."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-blue-200 rounded-full flex items-center justify-center mr-4">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-900">James M.</div>
                  <div className="text-sm text-gray-600">Premium Member</div>
                </div>
              </div>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
              <div className="flex items-center mb-6">
                <div className="flex text-blue-500">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-current" />)}
                </div>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                "The analysis is top-notch and the support team is always helpful. I've been using their service for over a year now."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-green-200 rounded-full flex items-center justify-center mr-4">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Sarah K.</div>
                  <div className="text-sm text-gray-600">VIP Member</div>
                </div>
              </div>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
              <div className="flex items-center mb-6">
                <div className="flex text-blue-500">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-current" />)}
                </div>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                "Professional service with excellent results. The predictions are well-researched and the success rate is impressive."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-purple-200 rounded-full flex items-center justify-center mr-4">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Michael R.</div>
                  <div className="text-sm text-gray-600">Gold Member</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 via-purple-600 to-blue-800 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-purple-600/90"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold mb-4 font-heading">Ready to Start Winning?</h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Join Kalaso Football Predictions today and experience the difference professional predictions can make.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/plans">
              <Button className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                Choose Your Package
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            {!user && <Link to="/auth">
                <Button variant="outline" className="border-2 border-white hover:bg-white px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 hover:scale-105 text-slate-900">
                  Create Free Account
                </Button>
              </Link>}
          </div>
        </div>
      </section>

      {/* Modern White Footer with Social Media */}
      <footer className="bg-white border-t border-gray-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <img src="/lovable-uploads/7799326b-6128-47df-9e48-b1abdc4cb85d.png" alt="Kalaso Football Predictions Logo" className="w-14 h-14 object-contain" />
                <div>
                  <h3 className="text-xl font-bold text-gray-900 font-heading">Kalaso Football Predictions</h3>
                  <p className="text-sm text-gray-500">Professional Predictions</p>
                </div>
              </div>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Your trusted partner for professional football predictions and winning strategies.
              </p>
              
              {/* Social Media Icons - Enhanced with shadows and better styling */}
              <div className="flex space-x-4">
                <button
                  onClick={() => handleSocialClick(socialLinks.whatsapp)}
                  className="group relative w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg hover:shadow-green-500/50"
                  aria-label="WhatsApp"
                >
                  <MessageCircle className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
                  <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </button>
                <button
                  onClick={() => handleSocialClick(socialLinks.facebook)}
                  className="group relative w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg hover:shadow-blue-500/50"
                  aria-label="Facebook"
                >
                  <Facebook className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
                  <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </button>
                <button
                  onClick={() => handleSocialClick(socialLinks.instagram)}
                  className="group relative w-12 h-12 bg-gradient-to-br from-pink-500 via-purple-500 to-orange-500 rounded-xl flex items-center justify-center hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg hover:shadow-pink-500/50"
                  aria-label="Instagram"
                >
                  <Instagram className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
                  <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </button>
                <button
                  onClick={() => handleSocialClick(socialLinks.gmail)}
                  className="group relative w-12 h-12 bg-gradient-to-br from-red-500 to-red-700 rounded-xl flex items-center justify-center hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg hover:shadow-red-500/50"
                  aria-label="Email"
                >
                  <Mail className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
                  <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </button>
                <button
                  onClick={() => handleSocialClick(socialLinks.tiktok)}
                  className="group relative w-12 h-12 bg-gradient-to-br from-gray-800 to-black rounded-xl flex items-center justify-center hover:scale-110 hover:rotate-3 transition-all duration-300 shadow-lg hover:shadow-gray-700/50"
                  aria-label="TikTok"
                >
                  <svg className="w-6 h-6 text-white group-hover:scale-110 transition-transform" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19.321 5.562a5.124 5.124 0 01-.443-.258 6.228 6.228 0 01-1.137-.966c-.849-.849-1.204-1.924-1.204-2.338v-.001C16.537 1.999 16.538 2 16.538 2h-3.685v12.8c0 2.278-1.844 4.127-4.127 4.127s-4.127-1.849-4.127-4.127 1.849-4.127 4.127-4.127c.284 0 .56.029.825.082V7.187c-.27-.041-.548-.062-.825-.062C4.785 7.125 1.8 10.11 1.8 13.751S4.785 20.377 8.426 20.377s6.626-2.985 6.626-6.626V8.987a9.483 9.483 0 004.969 1.37v-3.624c0-.001-.533.044-1.7-.171z"/>
                  </svg>
                  <div className="absolute inset-0 bg-white/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </button>
              </div>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-6 text-gray-900 font-heading">Quick Links</h4>
              <ul className="space-y-4">
                <li><Link to="/plans" className="text-gray-600 hover:text-blue-600 transition-colors duration-300 hover:pl-2">Packages</Link></li>
                <li><Link to="/free-tips" className="text-gray-600 hover:text-blue-600 transition-colors duration-300 hover:pl-2">Free Tips</Link></li>
                <li><Link to="/contact" className="text-gray-600 hover:text-blue-600 transition-colors duration-300 hover:pl-2">Contact</Link></li>
                {user ? <li><Link to="/app" className="text-gray-600 hover:text-blue-600 transition-colors duration-300 hover:pl-2">Dashboard</Link></li> : <li><Link to="/auth" className="text-gray-600 hover:text-blue-600 transition-colors duration-300 hover:pl-2">Sign In</Link></li>}
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-6 text-gray-900 font-heading">Support</h4>
              <ul className="space-y-4">
                <li><Link to="/help" className="text-gray-600 hover:text-blue-600 transition-colors duration-300 hover:pl-2">Help Center</Link></li>
                <li><Link to="/terms" className="text-gray-600 hover:text-blue-600 transition-colors duration-300 hover:pl-2">Terms of Service</Link></li>
                <li><button onClick={() => handleSocialClick(socialLinks.gmail)} className="text-gray-600 hover:text-blue-600 transition-colors duration-300 hover:pl-2 text-left">Email Support</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-6 text-gray-900 font-heading">Contact Info</h4>
              <ul className="space-y-4">
                <li className="flex items-center space-x-3">
                  <button 
                    onClick={() => handleSocialClick(socialLinks.phone)}
                    className="flex items-center space-x-3 text-gray-600 hover:text-blue-600 transition-colors duration-300"
                  >
                    <Phone className="w-5 h-5 text-blue-500" />
                    <span>+256 700 123 456</span>
                  </button>
                </li>
                <li className="flex items-center space-x-3">
                  <button 
                    onClick={() => handleSocialClick(socialLinks.gmail)}
                    className="flex items-center space-x-3 text-gray-600 hover:text-blue-600 transition-colors duration-300"
                  >
                    <Mail className="w-5 h-5 text-green-500" />
                    <span>support@sksurewins.com</span>
                  </button>
                </li>
                <li className="flex items-center space-x-3 text-gray-600">
                  <MapPin className="w-5 h-5 text-purple-500" />
                  <span>Kampala, Uganda</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-12 pt-8 text-center">
            <p className="text-gray-500">
              © 2024 Kalaso Football Predictions. All rights reserved. | Professional Football Predictions Platform
            </p>
          </div>
        </div>
      </footer>

      {/* Get App Modal */}
      <GetAppModal 
        open={getAppModalOpen}
        onOpenChange={setGetAppModalOpen}
      />
    </div>;
}
