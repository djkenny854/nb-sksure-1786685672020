import { useState } from 'react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { TransactionLoadingSkeleton } from '@/components/LoadingSkeleton'
import { useTransactions } from '@/hooks/useTransactions'
import { PageTransition } from '@/components/PageTransition'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { 
  CreditCard, 
  Download, 
  Search, 
  Filter,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  ArrowUpRight
} from 'lucide-react'
import { cn } from '@/lib/utils'

const formatAmount = (amount: number) => {
  return new Intl.NumberFormat('en-UG', {
    style: 'currency',
    currency: 'UGX',
    minimumFractionDigits: 0
  }).format(amount)
}

export default function Transactions() {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const { transactions, loading, getStatusIcon, getStatusColor } = useTransactions()

  if (loading) {
    return (
      <PageTransition>
        <div className="min-h-screen">
          <div className="sticky top-0 z-10 backdrop-blur-md bg-background/80 border-b border-border px-4 py-3">
            <h1 className="text-xl font-bold">Transactions</h1>
          </div>
          <TransactionLoadingSkeleton />
        </div>
      </PageTransition>
    )
  }

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.package_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.merchant_reference.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || transaction.status.toLowerCase() === statusFilter.toLowerCase()
    return matchesSearch && matchesStatus
  })

  const totalSpent = transactions
    .filter(t => t.status.toLowerCase() === 'completed')
    .reduce((sum, t) => sum + t.amount_ugx, 0)

  const thisMonthSpent = transactions
    .filter(t => {
      const isCompleted = t.status.toLowerCase() === 'completed'
      const isThisMonth = new Date(t.created_at).getMonth() === new Date().getMonth() &&
                          new Date(t.created_at).getFullYear() === new Date().getFullYear()
      return isCompleted && isThisMonth
    })
    .reduce((sum, t) => sum + t.amount_ugx, 0)

  const successRate = transactions.length > 0 
    ? Math.round((transactions.filter(t => t.status.toLowerCase() === 'completed').length / transactions.length) * 100)
    : 0

  const getStatusBadge = (status: string) => {
    const normalizedStatus = status.toLowerCase()
    switch (normalizedStatus) {
      case 'completed':
        return <Badge className="bg-green-500/20 text-green-600 border-green-500/30">Completed</Badge>
      case 'cancelled':
        return <Badge className="bg-orange-500/20 text-orange-600 border-orange-500/30">Cancelled</Badge>
      case 'failed':
        return <Badge className="bg-red-500/20 text-red-600 border-red-500/30">Failed</Badge>
      case 'pending':
        return <Badge className="bg-yellow-500/20 text-yellow-600 border-yellow-500/30">Pending</Badge>
      case 'expired':
        return <Badge className="bg-gray-500/20 text-gray-600 border-gray-500/30">Expired</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        {/* Sticky Header */}
        <div className="sticky top-0 z-10 backdrop-blur-md bg-background/95 border-b border-border">
          <div className="px-4 py-3 flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-foreground">Transactions</h1>
              <p className="text-sm text-muted-foreground">Your payment history</p>
            </div>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Download className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="p-4 space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-2xl bg-muted/50 p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <TrendingUp className="w-3 h-3" />
                Total
              </div>
              <p className="text-lg font-bold">{formatAmount(totalSpent)}</p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <CreditCard className="w-3 h-3" />
                This Month
              </div>
              <p className="text-lg font-bold">{formatAmount(thisMonthSpent)}</p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <CheckCircle className="w-3 h-3" />
                Success
              </div>
              <p className="text-lg font-bold">{successRate}%</p>
            </div>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="px-4 pb-4 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-muted/50 border-0 rounded-full"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px] bg-muted/50 border-0 rounded-full">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent className="bg-background">
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Transactions List */}
        <div className="divide-y divide-border">
          {filteredTransactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <CreditCard className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-bold mb-2">No transactions found</h3>
              <p className="text-muted-foreground max-w-xs">
                Your transaction history will appear here.
              </p>
            </div>
          ) : (
            filteredTransactions.map((transaction) => (
              <div key={transaction.id} className="px-4 py-4 hover:bg-muted/30 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-[15px] truncate">{transaction.package_name}</h3>
                      {getStatusBadge(transaction.status)}
                    </div>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      {new Date(transaction.created_at).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </p>
                    <p className="text-xs text-muted-foreground font-mono mt-1">
                      {transaction.merchant_reference}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-foreground">{formatAmount(transaction.amount_ugx)}</p>
                    <p className="text-xs text-muted-foreground">{transaction.payment_method}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </PageTransition>
  )
}
