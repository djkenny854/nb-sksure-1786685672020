
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Wrench, Clock, AlertTriangle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface MaintenanceSettings {
  maintenance_mode: boolean;
  maintenance_message?: string;
  maintenance_end_time?: string;
}

export function MaintenanceMode() {
  const [maintenanceInfo, setMaintenanceInfo] = useState<MaintenanceSettings | null>(null);

  useEffect(() => {
    const checkMaintenanceMode = async () => {
      try {
        const { data, error } = await supabase
          .from('system_settings')
          .select('key, value')
          .in('key', ['maintenance_mode', 'maintenance_message', 'maintenance_end_time']);

        if (error) {
          console.error('Error checking maintenance mode:', error);
          return;
        }

        const settings: MaintenanceSettings = {
          maintenance_mode: false,
          maintenance_message: 'System is under maintenance. Please check back later.',
          maintenance_end_time: undefined
        };

        data?.forEach((setting) => {
          if (setting.key === 'maintenance_mode') {
            settings.maintenance_mode = setting.value as boolean;
          } else if (setting.key === 'maintenance_message') {
            settings.maintenance_message = setting.value as string;
          } else if (setting.key === 'maintenance_end_time') {
            settings.maintenance_end_time = setting.value as string;
          }
        });

        setMaintenanceInfo(settings);
      } catch (error) {
        console.error('Error fetching maintenance settings:', error);
      }
    };

    checkMaintenanceMode();

    // Check maintenance mode every 30 seconds
    const interval = setInterval(checkMaintenanceMode, 30000);
    return () => clearInterval(interval);
  }, []);

  if (!maintenanceInfo?.maintenance_mode) {
    return null;
  }

  const formatEndTime = (endTime?: string) => {
    if (!endTime) return 'We will be back soon';
    
    try {
      const date = new Date(endTime);
      return `Expected to be back by ${date.toLocaleString()}`;
    } catch {
      return 'We will be back soon';
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md mx-auto shadow-xl border-border">
        <CardContent className="p-8 text-center">
          <div className="mb-6">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Wrench className="w-10 h-10 text-muted-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">System Maintenance</h1>
            <div className="flex items-center justify-center text-muted-foreground mb-4">
              <AlertTriangle className="w-5 h-5 mr-2" />
              <span className="text-sm font-medium">Temporarily Unavailable</span>
            </div>
          </div>

          <div className="space-y-4">
            <p className="text-muted-foreground leading-relaxed">
              {maintenanceInfo.maintenance_message}
            </p>

            <div className="bg-primary/10 rounded-lg p-4">
              <div className="flex items-center justify-center text-primary mb-2">
                <Clock className="w-5 h-5 mr-2" />
                <span className="font-medium">Estimated Return Time</span>
              </div>
              <p className="text-primary/80 text-sm">
                {formatEndTime(maintenanceInfo.maintenance_end_time)}
              </p>
            </div>

            <div className="pt-4">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <img 
                  src="/icons/icon-192.png" 
                  alt="Kalaso Football Predictions Logo" 
                  className="w-12 h-12 object-contain"
                />
                <div>
                  <h2 className="font-bold text-foreground">Kalaso Football Predictions</h2>
                  <p className="text-xs text-muted-foreground">Your trusted predictions platform</p>
                </div>
              </div>
              
              <p className="text-xs text-muted-foreground">
                We're working hard to improve your experience. Thank you for your patience!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
