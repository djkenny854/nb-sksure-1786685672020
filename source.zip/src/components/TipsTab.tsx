
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { hasAccess } from '@/lib/subscription';
import { useSubscriptions } from '@/hooks/useSubscriptions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Trophy, AlertCircle, ExternalLink, Calendar, Eye } from 'lucide-react';
import { EnhancedImageViewer } from '@/components/EnhancedImageViewer';

interface Ticket {
  id: string;
  ticket_name: string;
  status: string;
  comments?: string;
  created_at: string;
  updated_at: string;
  betika_link?: string;
  betpawa_link?: string;
  package_id: string;
  image_url?: string;
}

interface TicketMatch {
  id: string;
  match_name: string;
  prediction: string;
  odds: string;
  match_time: string;
}

interface Package {
  id: string;
  name: string;
  duration_days: number;
}

function getStatusIcon(status: string) {
  switch (status.toLowerCase()) {
    case 'won':
      return <Trophy className="h-3 w-3" />;
    case 'lost':
      return <AlertCircle className="h-3 w-3" />;
    case 'pending':
      return <Clock className="h-3 w-3" />;
    default:
      return <Clock className="h-3 w-3" />;
  }
}

function getStatusColor(status: string): "default" | "destructive" | "secondary" | "outline" {
  switch (status.toLowerCase()) {
    case 'won':
      return 'default';
    case 'lost':
      return 'destructive';
    case 'pending':
      return 'secondary';
    default:
      return 'outline';
  }
}

export function TipsTab() {
  const { user } = useAuth();
  const { subscriptions, loading: subscriptionsLoading } = useSubscriptions();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [ticketMatches, setTicketMatches] = useState<Record<string, TicketMatch[]>>({});
  const [packages, setPackages] = useState<Record<string, Package>>({});
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<{url: string, title: string} | null>(null);

  useEffect(() => {
    const fetchTickets = async () => {
      if (!user || subscriptionsLoading) {
        return;
      }

      setLoading(true);
      try {
        console.log('🎫 Fetching tickets for user:', user.id);
        console.log('📦 Active subscriptions:', subscriptions);

        // Get active package IDs from subscriptions
        const activePackageIds = subscriptions
          .filter(sub => hasAccess(sub))
          .map(sub => sub.package_id);

        console.log('📦 Active package IDs:', activePackageIds);

        if (activePackageIds.length === 0) {
          console.log('📦 No active subscriptions found');
          setTickets([]);
          setLoading(false);
          return;
        }

        // Fetch tickets for active packages
        const { data: ticketData, error: ticketError } = await supabase
          .from('tickets')
          .select('*')
          .in('package_id', activePackageIds)
          .order('created_at', { ascending: false });

        console.log('🎫 Fetched tickets:', ticketData);

        if (ticketError) {
          console.error('❌ Error fetching tickets:', ticketError);
          setLoading(false);
          return;
        }

        setTickets(ticketData || []);

        // Fetch ticket matches for each ticket
        if (ticketData && ticketData.length > 0) {
          const matchPromises = ticketData.map(ticket =>
            supabase
              .from('ticket_matches')
              .select('*')
              .eq('ticket_id', ticket.id)
              .order('match_time', { ascending: true })
          );

          const matchResults = await Promise.all(matchPromises);
          const matchesMap: Record<string, TicketMatch[]> = {};
          matchResults.forEach((result, index) => {
            if (result.error) {
              console.error(`❌ Error fetching matches for ticket ${ticketData[index].id}:`, result.error);
            } else {
              matchesMap[ticketData[index].id] = result.data || [];
            }
          });
          setTicketMatches(matchesMap);
        }

        // Fetch package details
        const { data: packageData, error: packageError } = await supabase
          .from('packages')
          .select('*')
          .in('id', activePackageIds);

        if (packageError) {
          console.error('❌ Error fetching packages:', packageError);
        } else {
          const packagesMap: Record<string, Package> = {};
          packageData?.forEach(pkg => {
            packagesMap[pkg.id] = pkg;
          });
          setPackages(packagesMap);
        }
      } catch (error) {
        console.error('💥 Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTickets();
  }, [user, subscriptions, subscriptionsLoading]);

  const handleImageClick = (imageUrl: string, ticketName: string) => {
    setSelectedImage({ url: imageUrl, title: ticketName });
  };

  const handleBettingLinkClick = (url: string, platform: string) => {
    if (url && url !== '#') {
      window.open(url, '_blank', 'noopener,noreferrer');
    } else {
      console.log(`${platform} link not available yet`);
    }
  };

  if (loading || subscriptionsLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">Authentication Required</h3>
        <p className="text-muted-foreground">Please sign in to view your betting tips.</p>
      </div>
    );
  }

  if (subscriptions.length === 0) {
    return (
      <div className="text-center py-12">
        <Trophy className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">No Active Subscriptions</h3>
        <p className="text-muted-foreground mb-4">
          You don't have any active subscriptions yet.
        </p>
        <p className="text-sm text-muted-foreground">
          Subscribe to a package to start receiving premium betting tips!
        </p>
      </div>
    );
  }

  if (tickets.length === 0) {
    return (
      <div className="space-y-6">
        {/* Show active subscriptions */}
        <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="h-4 w-4 text-primary" />
              <h3 className="font-semibold text-foreground">Active Subscriptions</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {subscriptions.map((sub, index) => (
                <Badge key={index} variant="default" className="bg-primary/10 text-primary border-primary/20">
                  {sub.packages?.name || `Package ${index + 1}`}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="text-center py-12">
          <Trophy className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Tips Available</h3>
          <p className="text-muted-foreground mb-4">
            No tips have been posted for your subscribed packages yet.
          </p>
          <p className="text-sm text-muted-foreground">
            Tips will appear here when our experts post them!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-6">
      {/* Show active subscriptions */}
      <Card className="bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="h-4 w-4 text-primary" />
            <h3 className="font-semibold text-foreground">Active Subscriptions</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {subscriptions.map((sub, index) => (
              <Badge key={index} variant="default" className="bg-primary/10 text-primary border-primary/20">
                {sub.packages?.name || `Package ${index + 1}`}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {tickets.map((ticket) => (
        <Card key={ticket.id} className="overflow-hidden">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <CardTitle className="text-lg">{ticket.ticket_name}</CardTitle>
                  <Badge 
                    variant={getStatusColor(ticket.status)}
                    className="flex items-center gap-1"
                  >
                    {getStatusIcon(ticket.status)}
                    {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                  </Badge>
                </div>
                
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {new Date(ticket.created_at).toLocaleDateString()}
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {new Date(ticket.updated_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>

                {packages[ticket.package_id] && (
                  <Badge variant="outline" className="w-fit">
                    {packages[ticket.package_id].name}
                  </Badge>
                )}
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            {ticket.comments && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm">{ticket.comments}</p>
              </div>
            )}

            {ticket.image_url && (
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Ticket Image</h4>
                <div 
                  className="relative cursor-pointer group rounded-lg overflow-hidden border bg-muted/50 hover:bg-muted transition-colors"
                  onClick={() => handleImageClick(ticket.image_url!, ticket.ticket_name)}
                >
                  <img
                    src={ticket.image_url}
                    alt={`${ticket.ticket_name} ticket`}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = '/placeholder.svg';
                    }}
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 backdrop-blur-sm rounded-full p-2">
                      <Eye className="h-5 w-5 text-gray-800" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {ticketMatches[ticket.id] && ticketMatches[ticket.id].length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Match Details</h4>
                <div className="space-y-2">
                  {ticketMatches[ticket.id].map((match) => (
                    <div key={match.id} className="p-3 border rounded-lg bg-card/50">
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="font-medium text-sm">{match.match_name}</h5>
                        <Badge variant="secondary" className="text-xs">
                          {match.odds}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">{match.prediction}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(match.match_time).toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3 pt-2">
              <Button
                onClick={() => handleBettingLinkClick(ticket.betika_link || '#', 'Betika')}
                variant="outline"
                size="sm"
                className="flex items-center gap-2 hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <img 
                  src="/lovable-uploads/cf277bb9-abd5-40b2-a407-36c79f97d25b.png" 
                  alt="Betika"
                  className="w-5 h-5 object-contain"
                />
                Bet on Betika
                <ExternalLink className="h-3 w-3" />
              </Button>
              
              <Button
                onClick={() => handleBettingLinkClick(ticket.betpawa_link || '#', 'BetPawa')}
                variant="outline"
                size="sm"
                className="flex items-center gap-2 hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <img 
                  src="/lovable-uploads/9675a0b3-a7d2-452b-a55b-f9900a0dd3bd.png" 
                  alt="BetPawa"
                  className="w-5 h-5 object-contain"
                />
                Bet on BetPawa
                <ExternalLink className="h-3 w-3" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}

      {selectedImage && (
        <EnhancedImageViewer
          isOpen={true}
          onClose={() => setSelectedImage(null)}
          imageUrl={selectedImage.url}
          title={selectedImage.title}
        />
      )}
    </div>
  );
}
