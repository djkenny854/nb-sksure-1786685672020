import { useEffect, useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Star, Trophy, TrendingUp, Users, Zap, Award } from 'lucide-react';
import { TicketHeatMap } from '@/components/TicketHeatMap';
import { useTipFeedback } from '@/hooks/useTipFeedback';
import { hasAccess, isInGracePeriod, getGraceDaysLeft } from '@/lib/subscription';

interface UserSubscription {
  id: string;
  package_id: string;
  start_date: string;
  end_date: string;
  is_active: boolean;
  packages: {
    name: string;
    duration_days: number;
    grace_period_days?: number;
  };
}

const StatsSkeleton = () => (
  <div className="grid grid-cols-2 gap-4">
    {Array.from({ length: 2 }).map((_, index) => (
      <Card key={index} className="animate-pulse">
        <CardContent className="p-4 text-center">
          <Skeleton className="h-8 w-8 mx-auto mb-2 rounded-full" />
          <Skeleton className="h-6 w-12 mx-auto mb-1" />
          <Skeleton className="h-4 w-20 mx-auto" />
        </CardContent>
      </Card>
    ))}
  </div>
);

export function HomeTab() {
  const { user, userProfile } = useAuth();
  const [activeSubscriptions, setActiveSubscriptions] = useState<UserSubscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [userStats, setUserStats] = useState({
    totalTipsReceived: 0,
    winRate: 85
  });
  
  // Initialize tip feedback listener for sound/haptic on wins
  useTipFeedback();

  const displayName = userProfile?.full_name || user?.email?.split('@')[0] || 'User';
  const isNewUser = !userProfile?.created_at || new Date().getTime() - new Date(userProfile.created_at).getTime() < 24 * 60 * 60 * 1000;

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    setLoading(true);
    await Promise.all([
      fetchActiveSubscriptions(),
      fetchUserStats()
    ]);
    setLoading(false);
  };

  const fetchActiveSubscriptions = async () => {
    const { data, error } = await supabase
      .from('user_subscriptions')
      .select(`
        *,
        packages (name, duration_days, grace_period_days)
      `)
      .eq('user_id', user?.id)
      .eq('is_active', true)
      .gte('end_date', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString());

    if (!error && data) {
      setActiveSubscriptions((data as any[]).filter((s) => hasAccess(s)) as any);
    }
  };

  const fetchUserStats = async () => {
    // Count tips received since user registration
    const { count: tipsCount } = await supabase
      .from('tickets')
      .select('*', { count: 'exact' })
      .eq('status', 'won')
      .gte('created_at', userProfile?.created_at || new Date().toISOString());

    setUserStats({
      totalTipsReceived: tipsCount || 0,
      winRate: 85
    });
  };

  const getDaysRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const today = new Date();
    return Math.max(0, Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  };

  return (
    <div 
      className="min-h-screen relative"
      style={{
        backgroundImage: `url('/lovable-uploads/f27983a8-624b-43ad-9332-61dbce9c9c91.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      {/* Glass overlay */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"></div>
      
      {/* Content container with glass effect */}
      <div className="relative z-10 p-6 space-y-6">
        {/* Welcome Section */}
        <div className="text-center backdrop-blur-md bg-white/10 border border-white/20 p-6 rounded-2xl shadow-2xl animate-fade-in">
          <h2 className="text-2xl font-bold text-white mb-2 animate-scale-in">
            {getGreeting()}, {displayName}! 👋
          </h2>
          <p className="text-blue-200 font-medium animate-slide-in-right">
            Welcome to Kalaso Football Predictions - Your Winning Partner
          </p>
          {isNewUser && (
            <div className="mt-3 inline-flex items-center gap-2 bg-green-500/20 backdrop-blur-sm text-green-100 px-3 py-1 rounded-full text-sm border border-green-400/30 animate-pulse">
              <Zap className="h-4 w-4" />
              New Member - Let's start winning together!
            </div>
          )}
        </div>

        {/* User Stats - Glass Effect */}
        <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <h3 className="text-lg font-semibold text-white mb-3 backdrop-blur-sm bg-black/20 p-2 rounded-lg inline-block">
            Your Performance
          </h3>
          {loading ? (
            <StatsSkeleton />
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <Card className="backdrop-blur-md bg-blue-500/20 border border-blue-400/30 shadow-2xl hover-scale animate-slide-in-right">
                <CardContent className="p-4 text-center">
                  <Trophy className="h-8 w-8 text-blue-200 mx-auto mb-2 animate-bounce" />
                  <div className="text-2xl font-bold text-white">{userStats.totalTipsReceived}</div>
                  <p className="text-sm text-blue-200">Tips Received</p>
                </CardContent>
              </Card>
              
              <Card className="backdrop-blur-md bg-green-500/20 border border-green-400/30 shadow-2xl hover-scale animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
                <CardContent className="p-4 text-center">
                  <Award className="h-8 w-8 text-green-200 mx-auto mb-2 animate-bounce" style={{ animationDelay: '0.2s' }} />
                  <div className="text-2xl font-bold text-white">{userStats.winRate}%</div>
                  <p className="text-sm text-green-200">Win Rate</p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {/* Heat Map - Visible on Mobile */}
        <div className="animate-fade-in lg:hidden" style={{ animationDelay: '0.3s' }}>
          <TicketHeatMap />
        </div>

        {/* Active Subscriptions */}
        <div className="animate-fade-in" style={{ animationDelay: '0.4s' }}>
          <h3 className="text-lg font-semibold text-white mb-3 backdrop-blur-sm bg-black/20 p-2 rounded-lg inline-block">
            Active Subscriptions
          </h3>
          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 2 }).map((_, index) => (
                <Card key={index} className="backdrop-blur-md bg-white/10 border border-white/20 animate-pulse">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <Skeleton className="h-5 w-32 mb-2 bg-white/20" />
                        <Skeleton className="h-4 w-24 bg-white/20" />
                      </div>
                      <Skeleton className="h-6 w-16 rounded-full bg-white/20" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : activeSubscriptions.length > 0 ? (
            <div className="space-y-3">
              {activeSubscriptions.map((subscription, index) => {
                const daysRemaining = getDaysRemaining(subscription.end_date);
                return (
                  <Card 
                    key={subscription.id} 
                    className="backdrop-blur-md bg-green-500/20 border border-green-400/30 shadow-2xl hover-scale animate-slide-in-right"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 bg-green-400/30 backdrop-blur-sm rounded-full flex items-center justify-center animate-pulse">
                            <Star className="h-5 w-5 text-green-200" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-white">
                              {subscription.packages.name}
                            </h4>
                            <p className="text-sm text-green-200">
                              {daysRemaining} days remaining
                            </p>
                          </div>
                        </div>
                        <Badge className="bg-green-500/30 backdrop-blur-sm text-green-100 border-green-400/50">
                          Active
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="backdrop-blur-md bg-white/10 border-2 border-dashed border-white/30 shadow-2xl">
              <CardContent className="p-8 text-center">
                <Star className="h-12 w-12 text-white/60 mx-auto mb-4 animate-spin" style={{ animationDuration: '3s' }} />
                <h4 className="font-semibold text-white mb-2">No Active Subscriptions</h4>
                <p className="text-sm text-white/80 mb-4">
                  Subscribe to a package to start receiving premium tips!
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Success Stories */}
        <Card className="backdrop-blur-md bg-emerald-500/20 border border-emerald-400/30 shadow-2xl animate-fade-in hover-scale" style={{ animationDelay: '0.6s' }}>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-white">
              <Users className="h-5 w-5 text-emerald-200 animate-bounce" />
              Community Success
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1 animate-scale-in">5,247</div>
              <p className="text-sm text-emerald-200">Members Won This Week</p>
              <div className="mt-3 flex justify-center gap-4 text-xs text-emerald-200">
                <span className="animate-pulse">📈 +12% from last week</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tips Section */}
        <Card className="backdrop-blur-md bg-purple-500/20 border border-purple-400/30 shadow-2xl animate-fade-in hover-scale" style={{ animationDelay: '0.8s' }}>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-white">
              <TrendingUp className="h-5 w-5 text-purple-200 animate-bounce" />
              Winning Tips
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3 p-3 backdrop-blur-sm bg-white/10 rounded-lg border border-white/20 animate-slide-in-right">
              <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 animate-pulse"></div>
              <p className="text-sm text-white/90">Check your tips daily for the best predictions</p>
            </div>
            <div className="flex items-start gap-3 p-3 backdrop-blur-sm bg-white/10 rounded-lg border border-white/20 animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
              <div className="w-2 h-2 bg-green-400 rounded-full mt-2 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
              <p className="text-sm text-white/90">Subscribe to multiple packages for better coverage</p>
            </div>
            <div className="flex items-start gap-3 p-3 backdrop-blur-sm bg-white/10 rounded-lg border border-white/20 animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 animate-pulse" style={{ animationDelay: '0.4s' }}></div>
              <p className="text-sm text-white/90">Bet responsibly and within your means</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
