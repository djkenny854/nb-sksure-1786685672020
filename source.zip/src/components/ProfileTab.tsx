import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { useSubscriptions } from '@/hooks/useSubscriptions';
import {
  LogOut,
  Phone,
  Mail,
  Calendar,
  Crown,
  ChevronRight,
  Shield,
  HelpCircle,
  FileText,
  Bell,
  Sun,
  Moon,
  Monitor,
  Pencil,
} from 'lucide-react';
import { format } from 'date-fns';
import PasswordChangeModal from './PasswordChangeModal';
import { PageTransition } from './PageTransition';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useTheme } from 'next-themes';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { PhoneInput } from './PhoneInput';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export default function ProfileTab() {
  const { user, userProfile, signOut } = useAuth();
  const { subscriptions, loading } = useSubscriptions();
  const [isSigningOut, setIsSigningOut] = useState(false);
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [phoneOpen, setPhoneOpen] = useState(false);
  const [phoneValue, setPhoneValue] = useState('');
  const [savingPhone, setSavingPhone] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (phoneOpen) setPhoneValue(userProfile?.phone || '');
  }, [phoneOpen, userProfile?.phone]);

  const handleSavePhone = async () => {
    if (!user) return;
    if (!/^256[0-9]{9}$/.test(phoneValue)) {
      toast({ title: 'Invalid phone', description: 'Use format 256XXXXXXXXX', variant: 'destructive' });
      return;
    }
    setSavingPhone(true);
    const { error } = await supabase
      .from('profiles')
      .update({ phone: phoneValue, updated_at: new Date().toISOString() })
      .eq('id', user.id);
    setSavingPhone(false);
    if (error) {
      toast({ title: 'Update failed', description: error.message, variant: 'destructive' });
      return;
    }
    toast({ title: 'Phone updated', description: 'Your phone number has been saved.' });
    setPhoneOpen(false);
    // Reflect immediately
    if (userProfile) userProfile.phone = phoneValue;
  };


  const handleSignOut = async () => {
    setIsSigningOut(true);
    await signOut();
    setIsSigningOut(false);
  };

  const activeSubscriptions = subscriptions.filter(sub => sub.is_active);

  const menuItems = [
    { icon: Bell, label: 'Notifications', path: '/app/notifications' },
    { icon: Shield, label: 'Privacy & Security', path: '/help' },
    { icon: HelpCircle, label: 'Help Center', path: '/help' },
    { icon: FileText, label: 'Terms of Service', path: '/terms' },
  ];

  const themeOptions = [
    { value: 'light', label: 'Light', icon: Sun },
    { value: 'dark', label: 'Dark', icon: Moon },
    { value: 'system', label: 'System', icon: Monitor },
  ];

  return (
    <PageTransition>
      <div className="min-h-screen">
        {/* Sticky Header */}
        <div className="sticky top-0 z-10 backdrop-blur-md bg-background/80 border-b border-border px-4 py-2">
          <h1 className="text-base font-bold">Profile</h1>
        </div>

        {/* Profile Header */}
        <div className="px-4 py-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-xl font-bold text-primary">
                {userProfile?.full_name?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || 'U'}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold truncate">{userProfile?.full_name || 'User'}</h2>
                {activeSubscriptions.length > 0 && (
                  <Badge className="bg-primary/20 text-primary text-xs">
                    <Crown className="w-2.5 h-2.5 mr-0.5" />
                    Premium
                  </Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground truncate">@{user?.email?.split('@')[0] || 'user'}</p>
            </div>
          </div>
        </div>

        {/* User Info */}
        <div className="px-4 py-3 border-b border-border space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
              <Mail className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs text-muted-foreground">Email</p>
              <p className="font-medium text-sm truncate">{user?.email || 'Not provided'}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setPhoneOpen(true)}
            className="w-full flex items-center gap-3 text-left hover:bg-muted/40 rounded-lg -mx-1 px-1 py-1 transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
              <Phone className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs text-muted-foreground">Phone</p>
              <p className="font-medium text-sm">{userProfile?.phone || 'Tap to add phone number'}</p>
            </div>
            <Pencil className="w-4 h-4 text-muted-foreground" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
              <Calendar className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs text-muted-foreground">Member since</p>
              <p className="font-medium text-sm">
                {userProfile?.created_at 
                  ? format(new Date(userProfile.created_at), 'MMM dd, yyyy') 
                  : 'Not available'}
              </p>
            </div>
          </div>
        </div>

        {/* Active Subscriptions */}
        {activeSubscriptions.length > 0 && (
          <div className="px-4 py-3 border-b border-border">
            <h3 className="font-semibold text-sm mb-2">Active Subscriptions</h3>
            <div className="space-y-2">
              {activeSubscriptions.map((subscription) => (
                <div 
                  key={subscription.id} 
                  className="p-3 rounded-xl bg-primary/5 border border-primary/20"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-sm">{subscription.packages?.name}</h4>
                      <p className="text-xs text-muted-foreground">
                        Expires {format(new Date(subscription.end_date), 'MMM dd, yyyy')}
                      </p>
                    </div>
                    <Badge className="bg-green-500/20 text-green-600 text-xs">Active</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Menu Items */}
        <div className="py-1">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={() => navigate(item.path)}
              className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                <item.icon className="w-4 h-4 text-muted-foreground" />
              </div>
              <span className="flex-1 text-left font-medium text-sm">{item.label}</span>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          ))}
        </div>

        {/* Theme Settings */}
        <div className="px-4 py-4 border-t border-border">
          <h3 className="font-semibold text-sm mb-3">Theme</h3>
          {mounted && (
            <div className="flex gap-2">
              {themeOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => setTheme(option.value)}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-colors",
                    theme === option.value 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted hover:bg-muted/80 text-muted-foreground"
                  )}
                >
                  <option.icon className="w-4 h-4" />
                  {option.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Account Settings */}
        <div className="p-4 border-t border-border space-y-3">
          <h3 className="font-semibold text-sm mb-3">Account Settings</h3>
          <PasswordChangeModal />
          <Button 
            variant="destructive" 
            onClick={handleSignOut}
            disabled={isSigningOut}
            className="w-full rounded-full text-sm"
            size="sm"
          >
            <LogOut className="w-4 h-4 mr-2" />
            {isSigningOut ? 'Signing Out...' : 'Sign Out'}
          </Button>
        </div>

        {loading && (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          </div>
        )}
      </div>

      <Dialog open={phoneOpen} onOpenChange={setPhoneOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Update phone number</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <label className="text-xs text-muted-foreground">Uganda phone (256XXXXXXXXX)</label>
            <PhoneInput value={phoneValue} onChange={setPhoneValue} placeholder="256700000000" />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPhoneOpen(false)} disabled={savingPhone}>Cancel</Button>
            <Button onClick={handleSavePhone} disabled={savingPhone}>{savingPhone ? 'Saving...' : 'Save'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTransition>

  );
}
