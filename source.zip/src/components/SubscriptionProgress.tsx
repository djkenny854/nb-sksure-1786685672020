import { useSubscriptions } from '@/hooks/useSubscriptions'
import { DashboardLoadingSkeleton } from './LoadingSkeleton'
import { Badge } from '@/components/ui/badge'
import { Clock, Sparkles, AlertTriangle } from 'lucide-react'
import { isInGracePeriod, getGraceDaysLeft } from '@/lib/subscription'
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

interface AnimatedCircularProgressProps {
  percentage: number
  size?: number
  strokeWidth?: number
  isExpiring?: boolean
}

function AnimatedCircularProgress({ 
  percentage, 
  size = 56, 
  strokeWidth = 4,
  isExpiring = false 
}: AnimatedCircularProgressProps) {
  const radius = (size - strokeWidth) / 2
  const circumference = 2 * Math.PI * radius
  const remaining = 100 - percentage
  const strokeDashoffset = circumference - (remaining / 100) * circumference
  
  const getGradientId = () => isExpiring ? 'expiring-gradient' : 'active-gradient'
  
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" style={{ width: size, height: size }}>
        <defs>
          <linearGradient id="active-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(var(--primary))" />
            <stop offset="100%" stopColor="hsl(142 76% 36%)" />
          </linearGradient>
          <linearGradient id="expiring-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(38 92% 50%)" />
            <stop offset="100%" stopColor="hsl(0 84% 60%)" />
          </linearGradient>
        </defs>
        {/* Background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="hsl(var(--muted))"
          strokeWidth={strokeWidth}
          fill="transparent"
          className="opacity-30"
        />
        {/* Progress circle */}
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={`url(#${getGradientId()})`}
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 1.5, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-sm font-bold text-foreground">{remaining.toFixed(0)}%</span>
      </div>
    </div>
  )
}

export function SubscriptionProgress() {
  const { subscriptions, loading, getTimeRemaining, getSubscriptionProgress } = useSubscriptions()
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 60000) // Update every minute
    return () => clearInterval(timer)
  }, [])

  if (loading) {
    return (
      <div className="space-y-3">
        {[1, 2].map(i => (
          <div key={i} className="bg-muted/30 rounded-xl p-4 animate-pulse">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-muted" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-muted rounded w-1/2" />
                <div className="h-3 bg-muted rounded w-1/3" />
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (subscriptions.length === 0) {
    return (
      <div className="bg-muted/30 rounded-xl p-6 text-center border border-border">
        <Sparkles className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
        <h3 className="font-semibold text-foreground mb-1">No Active Subscriptions</h3>
        <p className="text-sm text-muted-foreground">
          Subscribe to unlock premium tips
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {subscriptions.map((subscription, index) => {
        const timeRemaining = getTimeRemaining(subscription.end_date)
        const progress = getSubscriptionProgress(subscription.start_date, subscription.end_date)
        const inGrace = isInGracePeriod(subscription as any)
        const graceDaysLeft = getGraceDaysLeft(subscription as any)
        const isExpiring = inGrace || timeRemaining.days <= 3

        return (
          <motion.div 
            key={subscription.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={cn(
              "rounded-xl p-4 border transition-all hover:shadow-md",
              isExpiring 
                ? "bg-gradient-to-r from-orange-500/10 to-red-500/10 border-orange-500/30" 
                : "bg-gradient-to-r from-primary/10 to-green-500/10 border-primary/30"
            )}
          >
            <div className="flex items-center gap-4">
              {/* Circular Progress */}
              <AnimatedCircularProgress 
                percentage={progress} 
                isExpiring={isExpiring}
              />

              {/* Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-[15px] text-foreground truncate">
                    {subscription.packages?.name}
                  </h3>
                  <Badge className={cn(
                    "text-[10px] px-1.5 py-0 h-4",
                    isExpiring 
                      ? "bg-orange-500/20 text-orange-400 border-orange-500/30" 
                      : "bg-green-500/20 text-green-400 border-green-500/30"
                  )}>
                    {inGrace ? 'Grace period' : isExpiring ? 'Expiring' : 'Active'}
                  </Badge>
                </div>
                
                {inGrace ? (
                  <div className="flex items-center gap-1.5 text-[13px] text-orange-400 font-medium">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>
                      {graceDaysLeft} grace day{graceDaysLeft === 1 ? '' : 's'} left — renew to keep getting tips
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 text-[13px]">
                    <span className="text-foreground font-medium">
                      {timeRemaining.days}d {timeRemaining.hours}h
                    </span>
                    <span className="text-muted-foreground">remaining</span>
                  </div>
                )}

                <div className="flex items-center gap-1.5 mt-1 text-[12px] text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>Expires {new Date(subscription.end_date).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </motion.div>
        )
      })}
    </div>
  )
}
