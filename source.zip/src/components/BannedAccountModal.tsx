
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertTriangle, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface BannedAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BannedAccountModal({ isOpen, onClose }: BannedAccountModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            Account Under Review
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800 text-sm">
              Your account is currently under review and has been temporarily suspended.
            </p>
          </div>
          
          <div className="space-y-3">
            <p className="text-gray-700 text-sm">
              This means you cannot access premium features, tips, or make new subscriptions at this time.
            </p>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start gap-2">
                <Mail className="h-4 w-4 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-blue-800 font-medium text-sm">Need Help?</p>
                  <p className="text-blue-700 text-sm">
                    Please contact our admin team for support and more information about your account status.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <Button onClick={onClose} className="w-full">
            I Understand
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
