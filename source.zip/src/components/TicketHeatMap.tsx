import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useSubscriptions } from '@/hooks/useSubscriptions';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface TicketData {
  id: string;
  status: string;
  created_at: string;
  package_id: string;
  ticket_name: string;
}

interface PackageOption {
  id: string;
  name: string;
}

export function TicketHeatMap() {
  const { user } = useAuth();
  const { subscriptions } = useSubscriptions();
  const [tickets, setTickets] = useState<TicketData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPackage, setSelectedPackage] = useState<string>('all');
  const [packages, setPackages] = useState<PackageOption[]>([]);

  // Get subscribed package IDs
  const subscribedPackageIds = useMemo(() => {
    return subscriptions
      .filter(sub => sub.is_active)
      .map(sub => sub.package_id)
      .filter(Boolean) as string[];
  }, [subscriptions]);

  // Fetch packages user is subscribed to
  useEffect(() => {
    if (subscribedPackageIds.length > 0) {
      fetchPackages();
    }
  }, [subscribedPackageIds]);

  // Fetch tickets when package selection changes
  useEffect(() => {
    if (user && subscribedPackageIds.length > 0) {
      fetchTickets();
    } else {
      setLoading(false);
    }
  }, [user, selectedPackage, subscribedPackageIds]);

  const fetchPackages = async () => {
    if (subscribedPackageIds.length === 0) return;

    const { data, error } = await supabase
      .from('packages')
      .select('id, name')
      .in('id', subscribedPackageIds);

    if (!error && data) {
      setPackages(data);
    }
  };

  const fetchTickets = async () => {
    if (!user || subscribedPackageIds.length === 0) {
      setTickets([]);
      setLoading(false);
      return;
    }

    setLoading(true);

    let query = supabase
      .from('tickets')
      .select('id, status, created_at, package_id, ticket_name')
      .in('status', ['won', 'lost'])
      .order('created_at', { ascending: false })
      .limit(70);

    if (selectedPackage === 'all') {
      query = query.in('package_id', subscribedPackageIds);
    } else {
      query = query.eq('package_id', selectedPackage);
    }

    const { data, error } = await query;

    if (!error && data) {
      setTickets(data);
    }

    setLoading(false);
  };

  // Calculate stats
  const stats = useMemo(() => {
    const won = tickets.filter(t => t.status === 'won').length;
    const lost = tickets.filter(t => t.status === 'lost').length;
    const total = won + lost;
    const winRate = total > 0 ? (won / total) * 100 : 0;

    return { won, lost, total, winRate };
  }, [tickets]);

  // Generate heat map cells (7 columns like GitHub)
  const heatMapCells = useMemo(() => {
    const cells = [];
    for (let i = 0; i < 70; i++) {
      const ticket = tickets[i];
      cells.push({
        status: ticket?.status || null,
        name: ticket?.ticket_name || null,
        date: ticket?.created_at ? new Date(ticket.created_at).toLocaleDateString() : null
      });
    }
    return cells;
  }, [tickets]);

  if (subscribedPackageIds.length === 0) {
    return null;
  }

  return (
    <Card className="bg-background border border-border rounded-2xl overflow-hidden">
      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Performance</h3>
          {packages.length > 1 && (
            <Select value={selectedPackage} onValueChange={setSelectedPackage}>
              <SelectTrigger className="h-7 w-24 text-xs rounded-full border-border">
                <SelectValue placeholder="All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                {packages.map((pkg) => (
                  <SelectItem key={pkg.id} value={pkg.id}>
                    {pkg.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-4 mb-3 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-sm bg-green-500"></div>
            <span className="text-muted-foreground">{stats.won} won</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-sm bg-red-500"></div>
            <span className="text-muted-foreground">{stats.lost} lost</span>
          </div>
          <span className="text-foreground font-semibold ml-auto">{stats.winRate.toFixed(0)}%</span>
        </div>

        {/* GitHub-style heat map grid - 10 columns */}
        {loading ? (
          <div className="grid grid-cols-10 gap-[3px]">
            {Array.from({ length: 70 }).map((_, i) => (
              <div key={i} className="aspect-square rounded-sm bg-muted/30 animate-pulse" />
            ))}
          </div>
        ) : (
          <TooltipProvider delayDuration={0}>
            <div className="grid grid-cols-10 gap-[3px]">
              {heatMapCells.map((cell, index) => (
                <Tooltip key={index}>
                  <TooltipTrigger asChild>
                    <div
                      className={`
                        aspect-square rounded-sm transition-colors duration-150 cursor-default
                        ${cell.status === 'won' 
                          ? 'bg-green-500 hover:bg-green-400' 
                          : cell.status === 'lost' 
                            ? 'bg-red-500 hover:bg-red-400' 
                            : 'bg-muted/40'
                        }
                      `}
                    />
                  </TooltipTrigger>
                  {cell.status && (
                    <TooltipContent side="top" className="text-xs max-w-[200px]">
                      <p className="font-medium truncate">{cell.name}</p>
                      <p className={cell.status === 'won' ? 'text-green-400' : 'text-red-400'}>
                        {cell.status === 'won' ? '✓ Won' : '✗ Lost'} • {cell.date}
                      </p>
                    </TooltipContent>
                  )}
                </Tooltip>
              ))}
            </div>
          </TooltipProvider>
        )}
      </CardContent>
    </Card>
  );
}
