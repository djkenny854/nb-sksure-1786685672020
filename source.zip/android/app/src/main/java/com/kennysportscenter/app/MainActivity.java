package com.kennysportscenter.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
