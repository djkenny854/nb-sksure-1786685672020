# Native Google Sign-In Setup Guide for SK Tips Android App

This guide will help you set up **native Google Sign-In** for your Android app using Capacitor and `@capgo/capacitor-social-login`. This allows users to sign in with Google using the native account picker dialog instead of being redirected to a browser.

---

## 📋 Prerequisites

Before starting, ensure you have:

- ✅ Android Studio installed (latest stable version)
- ✅ The project exported to your GitHub repository
- ✅ Git installed and project cloned locally
- ✅ Node.js v18+ installed
- ✅ Your SHA-1 fingerprint ready (we'll get this in Step 2)

---

## 🚀 Step-by-Step Setup

### Step 1: Clone and Install Dependencies

```bash
# Clone your repository
git clone https://github.com/YOUR_USERNAME/skusers.git
cd skusers

# Install all dependencies
npm install

# Install the Capacitor Social Login plugin (CRITICAL - use this exact version)
npm install @capgo/capacitor-social-login@6.5.1
```

> ⚠️ **IMPORTANT**: Use version `6.5.1` specifically. Newer versions may have breaking changes with Google Sign-In.

---

### Step 2: Get Your SHA-1 Fingerprint

You need the SHA-1 fingerprint to register your app with Google Cloud Console.

#### Option A: Debug Signing Key (For Development/Testing)

1. Open the project in **Android Studio**:
   ```bash
   npx cap open android
   ```

2. In Android Studio, open the **Gradle** panel (right side)

3. Navigate to: `android → app → Tasks → android → signingReport`

4. Double-click `signingReport` to run it

5. Find the **SHA-1** under "Variant: debug" in the output:
   ```
   SHA1: XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX:XX
   ```

6. **Copy and save this SHA-1 fingerprint** - you'll need it in Step 4

#### Option B: Release Signing Key (For Production)

For production builds, you'll need to create a release keystore:

```bash
keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
```

Then get the SHA-1:
```bash
keytool -list -v -keystore release-key.jks -alias my-key-alias
```

---

### Step 3: Set Up Google Cloud Console

#### 3.1 Create or Select a Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Note your **Project ID**

#### 3.2 Enable Required APIs

1. Go to **APIs & Services → Library**
2. Search for and enable:
   - **Google+ API** (or People API)
   - **Google Identity Services**

#### 3.3 Configure OAuth Consent Screen

1. Go to **APIs & Services → OAuth consent screen**
2. Select **External** user type (unless you have Google Workspace)
3. Fill in the required fields:
   - **App name**: `SK Tips`
   - **User support email**: Your email
   - **Developer contact email**: Your email
4. Click **Save and Continue**
5. On **Scopes** page, add these scopes:
   - `.../auth/userinfo.email`
   - `.../auth/userinfo.profile`
   - `openid`
6. Click **Save and Continue**
7. Add test users if in testing mode
8. Click **Save and Continue** → **Back to Dashboard**

#### 3.4 Create OAuth Client IDs

You need to create **TWO** OAuth client IDs:

##### A. Web Application Client ID (REQUIRED)

1. Go to **APIs & Services → Credentials**
2. Click **+ CREATE CREDENTIALS** → **OAuth client ID**
3. Select **Web application**
4. Name: `SK Tips Web Client`
5. Under **Authorized JavaScript origins**, add:
   - `https://skusers.vercel.app`
   - `https://rvtsyeflswpconnhxkhs.supabase.co`
6. Under **Authorized redirect URIs**, add:
   - `https://rvtsyeflswpconnhxkhs.supabase.co/auth/v1/callback`
7. Click **Create**
8. **COPY AND SAVE** the **Client ID** (looks like: `XXXXX.apps.googleusercontent.com`)

##### B. Android Client ID (REQUIRED)

1. Click **+ CREATE CREDENTIALS** → **OAuth client ID**
2. Select **Android**
3. Name: `SK Tips Android`
4. **Package name**: `app.lovable.c711b52337a1438faaab3a19751a450f`
5. **SHA-1 certificate fingerprint**: Paste the SHA-1 from Step 2
6. Click **Create**

> 📝 **Note**: You don't need to copy the Android Client ID. The plugin uses the Web Client ID.

---

### Step 4: Configure Supabase

1. Go to your [Supabase Dashboard](https://supabase.com/dashboard)
2. Navigate to **Authentication → Providers**
3. Enable **Google** provider
4. Enter your **Web Client ID** from Step 3.4.A
5. Enter your **Web Client Secret** (from Google Cloud Console - click on your Web Client to see it)
6. Click **Save**

---

### Step 5: Update the App Code

Open `src/utils/nativeGoogleAuth.ts` and replace the placeholder with your **Web Client ID**:

```typescript
// Line 17 - Replace with your actual Web Client ID
export const GOOGLE_WEB_CLIENT_ID = 'YOUR_ACTUAL_WEB_CLIENT_ID.apps.googleusercontent.com';
```

Example:
```typescript
export const GOOGLE_WEB_CLIENT_ID = '123456789-abcdefghij.apps.googleusercontent.com';
```

---

### Step 6: Configure Android Native Files

#### 6.1 Update MainActivity.java

Open `android/app/src/main/java/app/lovable/c711b52337a1438faaab3a19751a450f/MainActivity.java`

Replace the entire contents with:

```java
package app.lovable.c711b52337a1438faaab3a19751a450f;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import ee.forgr.capacitor.social.login.ModifiedMainActivityForSocialLoginPlugin;

public class MainActivity extends BridgeActivity implements ModifiedMainActivityForSocialLoginPlugin {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ModifiedMainActivityForSocialLoginPlugin.Companion.onActivityResult(this, requestCode, resultCode, data);
    }
}
```

#### 6.2 Verify AndroidManifest.xml

Open `android/app/src/main/AndroidManifest.xml` and ensure you have internet permission:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

---

### Step 7: Build and Test

```bash
# Build the web assets
npm run build

# Sync with Android
npx cap sync android

# Open Android Studio
npx cap open android
```

In Android Studio:
1. Connect your Android device or start an emulator
2. Click **Run** (green play button) or press `Shift + F10`
3. Wait for the app to install and launch
4. Try clicking **Sign in with Google**

---

## 🐛 Troubleshooting

### Error: "DEVELOPER_ERROR"

This is the most common error. It means Google can't verify your app.

**Causes & Solutions:**

1. **SHA-1 Mismatch**
   - Make sure the SHA-1 in Google Cloud Console matches your signing key
   - For debug builds, use the debug keystore SHA-1
   - Re-run `signingReport` in Android Studio to verify

2. **Wrong Package Name**
   - Ensure the package name in Google Cloud Console is exactly:
     `app.lovable.c711b52337a1438faaab3a19751a450f`

3. **Missing Web Client ID**
   - You MUST create a Web Application OAuth client, not just Android
   - The plugin uses the Web Client ID, not the Android Client ID

4. **Consent Screen Not Published**
   - If in testing mode, make sure your Google account is added as a test user
   - Or publish the app to production in OAuth consent screen settings

### Error: "require is not defined"

This should be fixed now. The dynamic import prevents Vite from failing during build.

### Error: "Sign in cancelled"

The user cancelled the sign-in flow. This is normal behavior.

### Error: "Network error" or timeout

- Check your internet connection
- Ensure the device/emulator has internet access
- Check if Google Play Services is up to date on the device

### Google account picker doesn't appear

- Ensure Google Play Services is installed on the device/emulator
- Use a Google-certified emulator image (with Google APIs)
- On physical devices, make sure a Google account is signed in

---

## 📱 Testing Checklist

Before releasing, verify:

- [ ] App opens without crashes
- [ ] Clicking "Sign in with Google" shows the native account picker
- [ ] Selecting an account successfully signs you in
- [ ] You're redirected to `/app` after successful sign-in
- [ ] User data appears correctly in the profile
- [ ] Sign out works correctly
- [ ] Re-signing in works without issues

---

## 🔐 Production Release Checklist

Before publishing to Google Play Store:

1. **Create a production keystore** (if not already done)
2. **Add the release SHA-1** to Google Cloud Console (Android OAuth client)
3. **Publish the OAuth consent screen** to production
4. **Test with the release APK/AAB**

---

## 📚 Additional Resources

- [Capacitor Social Login Plugin Documentation](https://github.com/AntProGroup/capacitor-social-login)
- [Google Cloud Console](https://console.cloud.google.com/)
- [Supabase Auth Documentation](https://supabase.com/docs/guides/auth/social-login/auth-google)
- [Android App Signing](https://developer.android.com/studio/publish/app-signing)

---

## 🆘 Still Having Issues?

If you're still encountering problems:

1. Check the Android Studio **Logcat** for detailed error messages
2. Filter logs by "GoogleAuth" or "SocialLogin" to find relevant entries
3. Verify all client IDs match between Google Console and your code
4. Make sure you're using the correct version of the plugin (`6.5.1`)

---

**Last Updated**: February 2026
