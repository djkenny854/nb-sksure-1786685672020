
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ConfirmationRequest {
  email: string;
  confirmationUrl: string;
  name?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, confirmationUrl, name = "Champion" }: ConfirmationRequest = await req.json();

    const emailResponse = await resend.emails.send({
      from: "SK Sure Wins <noreply@skusers.vercel.app>",
      to: [email],
      subject: "🎉 Welcome to SK Sure Wins - Confirm Your Email",
      html: `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to SK Sure Wins</title>
          <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;600;700&display=swap" rel="stylesheet">
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;600;700&display=swap');
            
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }
            
            body {
              font-family: 'Raleway', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
              line-height: 1.6;
              color: #1f2937;
              background: linear-gradient(135deg, #10b981 0%, #059669 100%);
              margin: 0;
              padding: 20px;
              min-height: 100vh;
            }
            
            .email-container {
              max-width: 600px;
              margin: 0 auto;
              background: #ffffff;
              border-radius: 20px;
              overflow: hidden;
              box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
              animation: bounceInUp 0.8s ease-out;
            }
            
            @keyframes bounceInUp {
              0% {
                opacity: 0;
                transform: translateY(50px) scale(0.9);
              }
              60% {
                opacity: 1;
                transform: translateY(-10px) scale(1.05);
              }
              100% {
                opacity: 1;
                transform: translateY(0) scale(1);
              }
            }
            
            @keyframes sparkle {
              0%, 100% { transform: scale(1) rotate(0deg); opacity: 1; }
              25% { transform: scale(1.1) rotate(90deg); opacity: 0.8; }
              50% { transform: scale(1.2) rotate(180deg); opacity: 0.6; }
              75% { transform: scale(1.1) rotate(270deg); opacity: 0.8; }
            }
            
            @keyframes float {
              0%, 100% { transform: translateY(0px); }
              50% { transform: translateY(-10px); }
            }
            
            @keyframes glow {
              0%, 100% { box-shadow: 0 10px 20px rgba(16, 185, 129, 0.3); }
              50% { box-shadow: 0 15px 30px rgba(16, 185, 129, 0.5); }
            }
            
            .header {
              background: linear-gradient(135deg, #10b981 0%, #059669 100%);
              padding: 50px 20px;
              text-align: center;
              position: relative;
              overflow: hidden;
            }
            
            .header::before {
              content: '🎉';
              position: absolute;
              top: 20px;
              left: 30px;
              font-size: 30px;
              animation: sparkle 2s infinite;
            }
            
            .header::after {
              content: '🏆';
              position: absolute;
              top: 20px;
              right: 30px;
              font-size: 30px;
              animation: sparkle 2s infinite 0.5s;
            }
            
            .logo-container {
              position: relative;
              margin-bottom: 25px;
            }
            
            .logo {
              width: 90px;
              height: 90px;
              margin: 0 auto;
              background: white;
              border-radius: 25px;
              display: flex;
              align-items: center;
              justify-content: center;
              animation: float 3s ease-in-out infinite, glow 2s ease-in-out infinite;
              position: relative;
              z-index: 2;
            }
            
            .logo img {
              width: 70px;
              height: 70px;
              object-fit: contain;
            }
            
            .welcome-badge {
              position: absolute;
              top: -10px;
              right: -10px;
              background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
              color: white;
              padding: 5px 12px;
              border-radius: 20px;
              font-size: 12px;
              font-weight: 600;
              animation: pulse 2s infinite;
              z-index: 3;
            }
            
            @keyframes pulse {
              0% { transform: scale(1); }
              50% { transform: scale(1.1); }
              100% { transform: scale(1); }
            }
            
            .header h1 {
              color: white;
              font-size: 32px;
              font-weight: 700;
              margin-bottom: 8px;
              text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            
            .header p {
              color: rgba(255, 255, 255, 0.95);
              font-size: 16px;
              font-weight: 300;
            }
            
            .content {
              padding: 50px 40px;
              text-align: center;
            }
            
            .greeting {
              font-size: 26px;
              font-weight: 700;
              color: #1f2937;
              margin-bottom: 15px;
              background: linear-gradient(135deg, #10b981 0%, #059669 100%);
              -webkit-background-clip: text;
              -webkit-text-fill-color: transparent;
              background-clip: text;
            }
            
            .welcome-message {
              font-size: 18px;
              color: #4b5563;
              margin-bottom: 25px;
              line-height: 1.7;
            }
            
            .features-grid {
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
              gap: 20px;
              margin: 35px 0;
              padding: 0 10px;
            }
            
            .feature-item {
              background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
              border: 2px solid #bbf7d0;
              border-radius: 16px;
              padding: 20px 15px;
              text-align: center;
              transition: all 0.3s ease;
              animation: slideInUp 0.6s ease-out;
            }
            
            .feature-item:nth-child(1) { animation-delay: 0.1s; }
            .feature-item:nth-child(2) { animation-delay: 0.2s; }
            .feature-item:nth-child(3) { animation-delay: 0.3s; }
            
            @keyframes slideInUp {
              from {
                opacity: 0;
                transform: translateY(20px);
              }
              to {
                opacity: 1;
                transform: translateY(0);
              }
            }
            
            .feature-item:hover {
              transform: translateY(-5px);
              box-shadow: 0 10px 25px rgba(16, 185, 129, 0.2);
            }
            
            .feature-icon {
              font-size: 32px;
              margin-bottom: 10px;
              display: block;
            }
            
            .feature-title {
              font-size: 14px;
              font-weight: 600;
              color: #065f46;
              margin-bottom: 5px;
            }
            
            .feature-desc {
              font-size: 12px;
              color: #047857;
            }
            
            .confirm-button {
              display: inline-block;
              background: linear-gradient(135deg, #10b981 0%, #059669 100%);
              color: white;
              padding: 18px 45px;
              text-decoration: none;
              border-radius: 50px;
              font-weight: 700;
              font-size: 16px;
              box-shadow: 0 12px 24px rgba(16, 185, 129, 0.4);
              transition: all 0.3s ease;
              margin: 30px 0;
              position: relative;
              overflow: hidden;
              text-transform: uppercase;
              letter-spacing: 1px;
            }
            
            .confirm-button:hover {
              transform: translateY(-3px);
              box-shadow: 0 18px 36px rgba(16, 185, 129, 0.5);
            }
            
            .confirm-button::before {
              content: '';
              position: absolute;
              top: 0;
              left: -100%;
              width: 100%;
              height: 100%;
              background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
              transition: left 0.6s;
            }
            
            .confirm-button:hover::before {
              left: 100%;
            }
            
            .info-card {
              background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
              border: 2px solid #93c5fd;
              border-radius: 20px;
              padding: 25px;
              margin: 35px 0;
              position: relative;
            }
            
            .info-card::before {
              content: '💡';
              position: absolute;
              top: -12px;
              left: 25px;
              background: #3b82f6;
              width: 35px;
              height: 35px;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 18px;
              animation: bounce 2s infinite;
            }
            
            @keyframes bounce {
              0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
              40% { transform: translateY(-10px); }
              60% { transform: translateY(-5px); }
            }
            
            .info-text {
              color: #1e40af;
              font-size: 14px;
              font-weight: 500;
              margin-top: 10px;
              line-height: 1.6;
            }
            
            .url-container {
              background: #f1f5f9;
              border: 2px dashed #cbd5e1;
              border-radius: 12px;
              padding: 20px;
              margin: 25px 0;
              word-break: break-all;
            }
            
            .url-text {
              font-family: 'Courier New', monospace;
              font-size: 14px;
              color: #475569;
              line-height: 1.5;
            }
            
            .footer {
              background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
              padding: 40px 20px;
              text-align: center;
              border-top: 1px solid #e2e8f0;
            }
            
            .footer-content {
              max-width: 400px;
              margin: 0 auto;
            }
            
            .brand-name {
              font-size: 20px;
              font-weight: 700;
              background: linear-gradient(135deg, #10b981 0%, #059669 100%);
              -webkit-background-clip: text;
              -webkit-text-fill-color: transparent;
              background-clip: text;
              margin-bottom: 10px;
            }
            
            .footer-text {
              color: #6b7280;
              font-size: 14px;
              margin-bottom: 25px;
            }
            
            .stats-grid {
              display: grid;
              grid-template-columns: repeat(3, 1fr);
              gap: 15px;
              margin: 25px 0;
            }
            
            .stat-item {
              padding: 15px;
              background: white;
              border-radius: 12px;
              border: 1px solid #e5e7eb;
            }
            
            .stat-number {
              font-size: 20px;
              font-weight: 700;
              color: #10b981;
            }
            
            .stat-label {
              font-size: 12px;
              color: #6b7280;
              margin-top: 2px;
            }
            
            .divider {
              width: 80px;
              height: 4px;
              background: linear-gradient(135deg, #10b981 0%, #059669 100%);
              border-radius: 2px;
              margin: 30px auto;
            }
            
            @media only screen and (max-width: 600px) {
              .email-container {
                margin: 10px;
                border-radius: 16px;
              }
              
              .content {
                padding: 30px 20px;
              }
              
              .header {
                padding: 40px 20px;
              }
              
              .header h1 {
                font-size: 26px;
              }
              
              .greeting {
                font-size: 22px;
              }
              
              .confirm-button {
                padding: 16px 35px;
                font-size: 15px;
              }
              
              .features-grid {
                grid-template-columns: 1fr;
                gap: 15px;
              }
              
              .stats-grid {
                grid-template-columns: 1fr;
                gap: 10px;
              }
            }
          </style>
        </head>
        <body>
          <div class="email-container">
            <div class="header">
              <div class="logo-container">
                <div class="logo">
                  <img src="https://skusers.vercel.app/lovable-uploads/7799326b-6128-47df-9e48-b1abdc4cb85d.png" alt="SK Sure Wins" />
                </div>
                <div class="welcome-badge">NEW</div>
              </div>
              <h1>Welcome to SK Sure Wins!</h1>
              <p>Your journey to premium betting success starts here</p>
            </div>
            
            <div class="content">
              <div class="greeting">Hello ${name}! 🌟</div>
              
              <p class="welcome-message">
                🎉 <strong>Congratulations!</strong> You've just joined thousands of successful bettors who trust SK Sure Wins for premium sports betting tips and strategies.
              </p>
              
              <div class="features-grid">
                <div class="feature-item">
                  <span class="feature-icon">🎯</span>
                  <div class="feature-title">Expert Tips</div>
                  <div class="feature-desc">Professional analysis</div>
                </div>
                <div class="feature-item">
                  <span class="feature-icon">📊</span>
                  <div class="feature-title">High Success Rate</div>
                  <div class="feature-desc">Proven track record</div>
                </div>
                <div class="feature-item">
                  <span class="feature-icon">⚡</span>
                  <div class="feature-title">Real-time Updates</div>
                  <div class="feature-desc">Instant notifications</div>
                </div>
              </div>
              
              <a href="${confirmationUrl}" class="confirm-button">
                ✨ Confirm My Email & Start Winning
              </a>
              
              <div class="info-card">
                <div class="info-text">
                  <strong>🚀 What's Next?</strong><br>
                  After confirming your email, you'll get instant access to our premium dashboard with today's hottest tips, live updates, and exclusive betting strategies used by our top winners!
                </div>
              </div>
              
              <div class="divider"></div>
              
              <p style="color: #6b7280; font-size: 14px; margin-bottom: 15px;">
                Button not working? Copy and paste this link into your browser:
              </p>
              
              <div class="url-container">
                <div class="url-text">${confirmationUrl}</div>
              </div>
            </div>
            
            <div class="footer">
              <div class="footer-content">
                <div class="brand-name">SK Sure Wins</div>
                <p class="footer-text">
                  Join the winning team! Your success is our mission.
                </p>
                
                <div class="stats-grid">
                  <div class="stat-item">
                    <div class="stat-number">15K+</div>
                    <div class="stat-label">Happy Winners</div>
                  </div>
                  <div class="stat-item">
                    <div class="stat-number">85%</div>
                    <div class="stat-label">Success Rate</div>
                  </div>
                  <div class="stat-item">
                    <div class="stat-number">24/7</div>
                    <div class="stat-label">Support</div>
                  </div>
                </div>
                
                <p style="color: #9ca3af; font-size: 12px; margin-top: 25px;">
                  © 2024 SK Sure Wins. All rights reserved.<br>
                  Welcome aboard, champion! 🏆
                </p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log("Confirmation email sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error sending confirmation email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
