import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { createNylonPay } from "npm:@nile-squad/nylonpay-ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function normalizePhone(phone: string): string {
  let p = (phone || "").replace(/[^0-9]/g, "");
  if (p.startsWith("07") && p.length === 10) p = "256" + p.substring(1);
  if (p.length === 9) p = "256" + p;
  return p;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    const body = await req.json();
    const { userId, packageId, amount, phoneNumber, durationDays, description } = body ?? {};

    if (!userId || !packageId || !amount || !phoneNumber) {
      throw new Error("Missing required fields: userId, packageId, amount, phoneNumber");
    }
    if (typeof amount !== "number" || amount < 500) {
      throw new Error("Amount must be a number >= 500 UGX");
    }

    const formattedPhone = normalizePhone(phoneNumber);
    if (!/^256[0-9]{9}$/.test(formattedPhone)) {
      throw new Error("Invalid Uganda phone number");
    }

    // Load package
    const { data: pkg, error: pkgErr } = await supabase
      .from("packages")
      .select("name, duration_days")
      .eq("id", packageId)
      .single();
    if (pkgErr || !pkg) throw new Error("Package not found");

    // Load user profile for name
    const { data: profile } = await supabase
      .from("profiles")
      .select("full_name, email")
      .eq("id", userId)
      .single();

    const customerName = profile?.full_name || profile?.email || "Customer";
    const reference = crypto.randomUUID();
    const selectedDuration = Number.isFinite(Number(durationDays)) ? Math.max(1, Math.round(Number(durationDays))) : pkg.duration_days;
    const desc = description || `${pkg.name} - ${selectedDuration} days`;

    // Create pending transaction row
    const { data: tx, error: txErr } = await supabase
      .from("nylonpay_transactions")
      .insert({
        user_id: userId,
        package_id: packageId,
        reference,
        amount_ugx: amount,
        currency: "UGX",
        phone_number: formattedPhone,
        status: "pending",
        method: "mobileMoney",
        description: desc,
        metadata: { package_name: pkg.name, duration_days: selectedDuration },
      })
      .select()
      .single();
    if (txErr) throw new Error(`Failed to create transaction: ${txErr.message}`);

    // Initialize Nylon Pay
    const nylonpay = createNylonPay({
      apiKey: Deno.env.get("NYLONPAY_API_KEY") ?? "",
      apiSecret: Deno.env.get("NYLONPAY_API_SECRET") ?? "",
    });

    const collectArgs = {
      amount,
      currency: "UGX",
      customer: {
        name: customerName,
        phoneNumber: formattedPhone,
        email: profile?.email,
      },
      description: desc,
      reference,
      method: "mobileMoney",
      metadata: {
        userId,
        packageId,
        transactionId: tx.id,
      },
    } as any;

    // Retry the STK push up to 3 times — the provider intermittently returns
    // transient errors on the first attempt.
    let payment: any = null;
    let collectError: any = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        payment = await nylonpay.collectPayment(collectArgs);
        collectError = null;
        break;
      } catch (e) {
        collectError = e;
        console.error(`collectPayment attempt ${attempt} failed:`, (e as Error).message);
        if (attempt < 3) await new Promise((r) => setTimeout(r, attempt * 1000));
      }
    }

    if (!payment) {
      await supabase
        .from("nylonpay_transactions")
        .update({ status: "failed", error: (collectError as Error)?.message ?? "collectPayment failed" })
        .eq("id", tx.id);
      throw new Error((collectError as Error)?.message ?? "Could not reach mobile money provider. Please try again.");
    }

    // Background: wait for terminal state and update DB
    const settle = async () => {
      try {
        const transaction: any = await payment.wait();
        const finalStatus =
          transaction?.status === "success" || transaction?.status === "successful" || transaction?.status === "completed"
            ? "completed"
            : transaction?.status === "failed"
            ? "failed"
            : transaction?.status || "failed";

        const update: Record<string, any> = {
          status: finalStatus,
          nylonpay_transaction_id: transaction?.id ?? transaction?.transactionId ?? null,
          provider: transaction?.provider ?? null,
          metadata: { ...(tx.metadata ?? {}), transaction },
        };
        if (transaction?.error) update.error = String(transaction.error);

        await supabase
          .from("nylonpay_transactions")
          .update(update)
          .eq("id", tx.id);

        if (finalStatus === "completed") {
          const { error: subErr } = await supabase.rpc("extend_or_create_subscription_robust", {
            p_user_id: userId,
            p_package_id: packageId,
            p_payment_reference: reference,
            p_duration_days: selectedDuration,
          });
          if (subErr) {
            console.error("Subscription activation failed:", subErr);
            await supabase
              .from("nylonpay_transactions")
              .update({ error: `sub_activation: ${subErr.message}` })
              .eq("id", tx.id);
          }
        }
      } catch (e) {
        const msg = (e as Error).message || "";
        console.error("Payment wait error:", msg);
        // Transient network/timeout issues must NOT mark a live prompt as failed —
        // leave it pending so the webhook / status polling resolves it.
        const transient = /timeout|timed out|network|fetch|socket|ECONN|502|503|504/i.test(msg);
        await supabase
          .from("nylonpay_transactions")
          .update(transient ? { error: msg } : { status: "failed", error: msg })
          .eq("id", tx.id);
      }
    };

    // @ts-ignore EdgeRuntime is provided in Supabase Edge Functions
    if (typeof EdgeRuntime !== "undefined" && EdgeRuntime.waitUntil) {
      // @ts-ignore
      EdgeRuntime.waitUntil(settle());
    } else {
      settle();
    }

    return new Response(
      JSON.stringify({
        success: true,
        reference,
        transactionId: tx.id,
        message: "Payment prompt sent. Approve on your phone.",
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("initiate-nylonpay-payment error:", error);
    return new Response(
      JSON.stringify({ success: false, error: error?.message ?? "Payment initiation failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
