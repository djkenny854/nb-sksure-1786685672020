import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.51.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { orderTrackingId } = await req.json()
    
    console.log('🚫 Cancelling pending payment for:', orderTrackingId)

    if (!orderTrackingId) {
      throw new Error('Order tracking ID is required')
    }

    // Update the transaction status to CANCELLED
    const { data, error } = await supabase
      .from('pesapal_transactions')
      .update({ 
        status: 'CANCELLED',
        updated_at: new Date().toISOString()
      })
      .eq('order_tracking_id', orderTrackingId)
      .eq('status', 'pending')
      .select()
      .single()

    if (error) {
      console.error('❌ Error cancelling transaction:', error)
      throw error
    }

    console.log('✅ Transaction cancelled successfully:', data)

    return new Response(
      JSON.stringify({ success: true, transaction: data }),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        } 
      }
    )
  } catch (error) {
    console.error('💥 Error in cancel-pending-payment:', error)
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { 
        status: 400,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        } 
      }
    )
  }
})