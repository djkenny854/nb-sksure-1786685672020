
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const logError = async (supabase: any, error: any, context: string, params?: any) => {
  try {
    let errorMessage: string;
    let errorDetails: any;

    if (error?.response?.data) {
      errorMessage = JSON.stringify(error.response.data);
      errorDetails = {
        context,
        response_data: error.response.data,
        response_status: error.response.status,
        stack: error.stack,
        timestamp: new Date().toISOString()
      };
    } else if (typeof error === 'object' && error !== null) {
      errorMessage = JSON.stringify(error);
      errorDetails = {
        context,
        full_error: error,
        stack: error.stack,
        timestamp: new Date().toISOString()
      };
    } else {
      errorMessage = String(error);
      errorDetails = {
        context,
        error_string: errorMessage,
        timestamp: new Date().toISOString()
      };
    }
    
    await supabase.from('payment_error_logs').insert({
      error_type: error.name || 'WEBHOOK_ERROR',
      error_message: errorMessage,
      error_details: errorDetails,
      function_name: 'pesapal-webhook-production'
    });
  } catch (logErr) {
    console.error('❌ Failed to log webhook error:', logErr);
  }
};

const getValidToken = async (): Promise<string> => {
  const environment = Deno.env.get('PESAPAL_ENVIRONMENT') || 'sandbox';
  const consumerKey = Deno.env.get('PESAPAL_CONSUMER_KEY');
  const consumerSecret = Deno.env.get('PESAPAL_CONSUMER_SECRET');
  
  if (!consumerKey || !consumerSecret) {
    throw new Error('Missing PesaPal credentials');
  }

  const baseUrl = environment === 'live' 
    ? 'https://pay.pesapal.com/v3/api'
    : 'https://cybqa.pesapal.com/pesapalv3/api';

  const tokenResponse = await fetch(`${baseUrl}/Auth/RequestToken`, {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      consumer_key: consumerKey,
      consumer_secret: consumerSecret,
    }),
  });

  if (!tokenResponse.ok) {
    const errorText = await tokenResponse.text();
    throw new Error(`Token request failed: ${tokenResponse.status} - ${errorText}`);
  }

  const tokenData = await tokenResponse.json();
  
  if (tokenData.error || !tokenData.token) {
    throw new Error(`Token error: ${JSON.stringify(tokenData)}`);
  }

  return tokenData.token;
};

const getTransactionStatus = async (token: string, orderTrackingId: string) => {
  const environment = Deno.env.get('PESAPAL_ENVIRONMENT') || 'sandbox';
  const baseUrl = environment === 'live' 
    ? 'https://pay.pesapal.com/v3/api'
    : 'https://cybqa.pesapal.com/pesapalv3/api';

  const statusResponse = await fetch(`${baseUrl}/Transactions/GetTransactionStatus?orderTrackingId=${orderTrackingId}`, {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!statusResponse.ok) {
    const errorText = await statusResponse.text();
    throw new Error(`Status request failed: ${statusResponse.status} - ${errorText}`);
  }

  const statusData = await statusResponse.json();
  
  if (statusData.error) {
    throw new Error(`Status error: ${JSON.stringify(statusData)}`);
  }

  return statusData;
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const url = new URL(req.url);
    const orderTrackingId = url.searchParams.get('OrderTrackingId');
    const orderMerchantReference = url.searchParams.get('OrderMerchantReference');

    console.log(`🔔 PRODUCTION Webhook received:`, {
      orderTrackingId,
      orderMerchantReference,
      method: req.method,
      allParams: Object.fromEntries(url.searchParams.entries()),
      timestamp: new Date().toISOString()
    });

    if (!orderTrackingId && !orderMerchantReference) {
      console.error('❌ Missing both OrderTrackingId and OrderMerchantReference parameters');
      return new Response('Missing tracking parameters', { 
        headers: corsHeaders, 
        status: 400 
      });
    }

    // Use the new database function to find the transaction
    const { data: transactionData, error: transactionError } = await supabaseClient
      .rpc('find_pesapal_transaction', {
        p_order_tracking_id: orderTrackingId,
        p_merchant_reference: orderMerchantReference
      })

    if (transactionError) {
      await logError(supabaseClient, transactionError, 'find_transaction', { orderTrackingId, orderMerchantReference });
      throw new Error(`Database error finding transaction: ${JSON.stringify(transactionError)}`);
    }

    if (!transactionData || transactionData.length === 0) {
      console.log(`⚠️ Transaction not found for tracking ID: ${orderTrackingId}`);
      // Return success to prevent PesaPal from retrying
      return new Response('Transaction not found', { 
        headers: corsHeaders, 
        status: 200 
      });
    }

    const transaction = transactionData[0];
    console.log(`📋 Found transaction: ${transaction.id} (Status: ${transaction.status})`);

    // Skip if already processed successfully
    if (transaction.status === 'completed') {
      console.log(`✓ Transaction already completed: ${transaction.status}`);
      return new Response('Already processed as completed', { 
        headers: corsHeaders, 
        status: 200 
      });
    }

    // Get fresh token and check transaction status
    const token = await getValidToken();
    const statusData = await getTransactionStatus(token, orderTrackingId);

    console.log(`📊 Transaction status from PesaPal:`, {
      status: statusData.status,
      payment_status_description: statusData.payment_status_description,
      payment_method: statusData.payment_method,
      amount: statusData.amount,
      merchant_reference: statusData.merchant_reference
    });

    // Update transaction with latest info
    const updateData: any = {
      payment_status_description: statusData.payment_status_description,
      payment_method: statusData.payment_method,
      pesapal_response: statusData,
      updated_at: new Date().toISOString()
    };

    let subscriptionResult = null;

    // Process based on status
    if (statusData.status === 'COMPLETED' || statusData.payment_status_description === 'Completed') {
      updateData.status = 'completed';
      
      // Create or extend subscription using the new robust function
      try {
        const { data: subscriptionResponse, error: subscriptionError } = await supabaseClient
          .rpc('extend_or_create_subscription_robust', {
            p_user_id: transaction.user_id,
            p_package_id: transaction.package_id,
            p_payment_reference: orderTrackingId,
            p_duration_days: transaction.package_duration_days || 30
          });

        if (subscriptionError) {
          throw subscriptionError;
        }

        if (!subscriptionResponse.success) {
          throw new Error(subscriptionResponse.error);
        }

        subscriptionResult = subscriptionResponse;
        console.log(`✅ Subscription created/extended:`, subscriptionResult);

      } catch (subscriptionError) {
        await logError(supabaseClient, subscriptionError, 'create_extend_subscription', {
          userId: transaction.user_id,
          packageId: transaction.package_id,
          transactionId: transaction.id
        });
        
        // Don't fail the webhook, but log the error
        console.error('❌ Subscription creation failed:', JSON.stringify(subscriptionError));
        updateData.last_error = `Subscription creation failed: ${JSON.stringify(subscriptionError)}`;
      }

    } else if (statusData.status === 'FAILED' || statusData.status === 'INVALID') {
      updateData.status = 'failed';
      updateData.last_error = statusData.payment_status_description || 'Payment failed';
      
    } else {
      // Still pending or other status
      updateData.status = 'pending';
      console.log(`⏳ Transaction still pending: ${statusData.status}`);
    }

    // Update the transaction
    const { error: updateError } = await supabaseClient
      .from('pesapal_transactions')
      .update(updateData)
      .eq('id', transaction.id);

    if (updateError) {
      await logError(supabaseClient, updateError, 'update_transaction', { 
        transactionId: transaction.id,
        updateData 
      });
      throw new Error(`Failed to update transaction: ${JSON.stringify(updateError)}`);
    }

    console.log(`💾 Transaction updated successfully:`, {
      transactionId: transaction.id,
      newStatus: updateData.status,
      subscriptionResult: subscriptionResult,
      timestamp: new Date().toISOString()
    });

    return new Response(
      JSON.stringify({
        success: true,
        status: updateData.status,
        message: 'Webhook processed successfully',
        transaction_id: transaction.id,
        subscription_result: subscriptionResult
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('🔥 CRITICAL Webhook processing error:', {
      error: JSON.stringify(error),
      stack: error.stack,
      timestamp: new Date().toISOString()
    });
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    await logError(supabaseClient, error, 'webhook_processing_critical', { 
      url: req.url,
      method: req.method 
    });

    // Return 200 to prevent PesaPal from retrying
    return new Response(
      JSON.stringify({
        success: false,
        error: 'Webhook processing failed',
        message: JSON.stringify(error)
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  }
});
