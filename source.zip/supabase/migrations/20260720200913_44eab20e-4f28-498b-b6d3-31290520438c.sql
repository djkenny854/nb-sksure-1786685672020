
CREATE TABLE public.nylonpay_transactions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  package_id uuid,
  reference uuid NOT NULL UNIQUE,
  amount_ugx integer NOT NULL,
  currency text NOT NULL DEFAULT 'UGX',
  phone_number text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  nylonpay_transaction_id text,
  provider text,
  method text DEFAULT 'mobileMoney',
  description text,
  metadata jsonb DEFAULT '{}'::jsonb,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.nylonpay_transactions TO authenticated;
GRANT ALL ON public.nylonpay_transactions TO service_role;

ALTER TABLE public.nylonpay_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own nylonpay transactions"
ON public.nylonpay_transactions
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own nylonpay transactions"
ON public.nylonpay_transactions
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Service role manages nylonpay transactions"
ON public.nylonpay_transactions
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

CREATE INDEX idx_nylonpay_tx_user ON public.nylonpay_transactions(user_id, created_at DESC);
CREATE INDEX idx_nylonpay_tx_reference ON public.nylonpay_transactions(reference);
CREATE INDEX idx_nylonpay_tx_status ON public.nylonpay_transactions(status);

CREATE TRIGGER update_nylonpay_tx_updated_at
BEFORE UPDATE ON public.nylonpay_transactions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER PUBLICATION supabase_realtime ADD TABLE public.nylonpay_transactions;
