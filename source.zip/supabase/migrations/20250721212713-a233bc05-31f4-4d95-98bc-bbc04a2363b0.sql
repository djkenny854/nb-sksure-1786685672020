
-- Add error logging table for payment debugging
CREATE TABLE IF NOT EXISTS payment_error_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  transaction_id UUID,
  error_type TEXT NOT NULL,
  error_message TEXT NOT NULL,
  error_details JSONB,
  function_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies for error logs
ALTER TABLE payment_error_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage payment error logs" ON payment_error_logs
  FOR ALL USING (is_admin(auth.uid()));

-- Add retry tracking to pesapal_transactions
ALTER TABLE pesapal_transactions 
ADD COLUMN IF NOT EXISTS retry_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_error TEXT,
ADD COLUMN IF NOT EXISTS token_used TEXT,
ADD COLUMN IF NOT EXISTS api_version TEXT DEFAULT 'v3';

-- Create phone validation function
CREATE OR REPLACE FUNCTION validate_ug_phone(phone TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  -- Remove any spaces, dashes, or plus signs
  phone := REGEXP_REPLACE(phone, '[^0-9]', '', 'g');
  
  -- Check if it matches Uganda format: 256xxxxxxxxx (12 digits total)
  -- OR 07xxxxxxxx (10 digits starting with 07) which we'll convert
  IF phone ~ '^256[0-9]{9}$' THEN
    RETURN TRUE;
  ELSIF phone ~ '^07[0-9]{8}$' THEN
    RETURN TRUE;
  ELSIF phone ~ '^[0-9]{9}$' THEN
    -- 9 digits, assume it's missing the 256 prefix
    RETURN TRUE;
  END IF;
  
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql;

-- Create function to normalize phone numbers to Uganda format
CREATE OR REPLACE FUNCTION normalize_ug_phone(phone TEXT)
RETURNS TEXT AS $$
BEGIN
  -- Remove any spaces, dashes, or plus signs
  phone := REGEXP_REPLACE(phone, '[^0-9]', '', 'g');
  
  -- Convert 07xxxxxxxx to 256xxxxxxxx
  IF phone ~ '^07[0-9]{8}$' THEN
    RETURN '256' || SUBSTRING(phone FROM 2);
  END IF;
  
  -- Add 256 prefix if missing (assuming 9 digits)
  IF phone ~ '^[0-9]{9}$' THEN
    RETURN '256' || phone;
  END IF;
  
  -- Return as-is if already in correct format
  IF phone ~ '^256[0-9]{9}$' THEN
    RETURN phone;
  END IF;
  
  -- If we can't normalize, return original
  RETURN phone;
END;
$$ LANGUAGE plpgsql;

-- Create function to prevent duplicate active subscriptions and extend existing ones
CREATE OR REPLACE FUNCTION extend_or_create_subscription(
  p_user_id UUID,
  p_package_id UUID,
  p_payment_reference TEXT,
  p_duration_days INTEGER
)
RETURNS UUID AS $$
DECLARE
  existing_subscription_id UUID;
  new_end_date TIMESTAMP WITH TIME ZONE;
  subscription_id UUID;
BEGIN
  -- Check for existing active subscription for this package
  SELECT id INTO existing_subscription_id
  FROM user_subscriptions
  WHERE user_id = p_user_id 
    AND package_id = p_package_id 
    AND is_active = true 
    AND end_date > NOW();

  IF existing_subscription_id IS NOT NULL THEN
    -- Extend existing subscription
    SELECT end_date INTO new_end_date
    FROM user_subscriptions
    WHERE id = existing_subscription_id;
    
    -- Add duration to existing end date
    new_end_date := new_end_date + (p_duration_days || ' days')::INTERVAL;
    
    UPDATE user_subscriptions
    SET 
      end_date = new_end_date,
      updated_at = NOW(),
      payment_reference = p_payment_reference
    WHERE id = existing_subscription_id;
    
    RETURN existing_subscription_id;
  ELSE
    -- Create new subscription
    INSERT INTO user_subscriptions (
      user_id,
      package_id,
      start_date,
      end_date,
      payment_reference,
      is_active
    ) VALUES (
      p_user_id,
      p_package_id,
      NOW(),
      NOW() + (p_duration_days || ' days')::INTERVAL,
      p_payment_reference,
      true
    ) RETURNING id INTO subscription_id;
    
    RETURN subscription_id;
  END IF;
END;
$$ LANGUAGE plpgsql;
