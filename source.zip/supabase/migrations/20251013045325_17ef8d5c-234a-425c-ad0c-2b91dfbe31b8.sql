-- Update the function to exclude CANCELLED transactions from pending payment check
CREATE OR REPLACE FUNCTION public.has_recent_pending_payment(p_user_id uuid, p_package_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM pesapal_transactions
    WHERE user_id = p_user_id
      AND package_id = p_package_id
      AND status = 'pending'
      AND created_at > NOW() - INTERVAL '2 minutes'
  );
END;
$function$;