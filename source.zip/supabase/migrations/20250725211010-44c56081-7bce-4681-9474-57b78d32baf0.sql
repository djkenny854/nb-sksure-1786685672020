
-- Create function to get user notifications (including broadcast notifications)
CREATE OR REPLACE FUNCTION get_user_notifications(user_id UUID)
RETURNS TABLE(
  id UUID,
  user_id UUID,
  title TEXT,
  message TEXT,
  type TEXT,
  is_read BOOLEAN,
  created_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  is_broadcast BOOLEAN
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    n.id,
    n.user_id,
    n.title,
    n.message,
    n.type,
    n.is_read,
    n.created_at,
    n.expires_at,
    (n.user_id IS NULL) as is_broadcast
  FROM notifications n
  WHERE (n.user_id = get_user_notifications.user_id OR n.user_id IS NULL)
    AND (n.expires_at IS NULL OR n.expires_at > NOW())
  ORDER BY n.created_at DESC;
END;
$$;

-- Create function to mark notification as read
CREATE OR REPLACE FUNCTION mark_notification_read(notification_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE notifications 
  SET is_read = true, updated_at = NOW()
  WHERE id = notification_id 
    AND (user_id = auth.uid() OR user_id IS NULL);
END;
$$;

-- Create function to mark all notifications as read for a user
CREATE OR REPLACE FUNCTION mark_all_notifications_read(user_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE notifications 
  SET is_read = true, updated_at = NOW()
  WHERE (notifications.user_id = mark_all_notifications_read.user_id OR notifications.user_id IS NULL)
    AND is_read = false;
END;
$$;

-- Create function to get tickets with their matches
CREATE OR REPLACE FUNCTION get_user_tickets(user_id UUID)
RETURNS TABLE(
  id UUID,
  ticket_name TEXT,
  package_id UUID,
  status TEXT,
  comments TEXT,
  betika_link TEXT,
  betpawa_link TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE,
  package_name TEXT,
  matches JSONB
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    t.id,
    t.ticket_name,
    t.package_id,
    t.status::TEXT,
    t.comments,
    t.betika_link,
    t.betpawa_link,
    t.created_at,
    t.updated_at,
    p.name as package_name,
    COALESCE(
      (
        SELECT jsonb_agg(
          jsonb_build_object(
            'id', tm.id,
            'match_name', tm.match_name,
            'match_time', tm.match_time,
            'prediction', tm.prediction,
            'odds', tm.odds
          )
        )
        FROM ticket_matches tm
        WHERE tm.ticket_id = t.id
      ),
      '[]'::jsonb
    ) as matches
  FROM tickets t
  LEFT JOIN packages p ON p.id = t.package_id
  WHERE EXISTS (
    SELECT 1 FROM user_subscriptions us
    WHERE us.user_id = get_user_tickets.user_id
      AND us.package_id = t.package_id
      AND us.is_active = true
      AND us.end_date > NOW()
  )
  ORDER BY t.created_at DESC;
END;
$$;

-- Create function to get free tickets with their matches
CREATE OR REPLACE FUNCTION get_free_tickets()
RETURNS TABLE(
  id UUID,
  ticket_name TEXT,
  status TEXT,
  comments TEXT,
  betika_link TEXT,
  betpawa_link TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE,
  matches JSONB
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ft.id,
    ft.ticket_name,
    ft.status,
    ft.comments,
    ft.betika_link,
    ft.betpawa_link,
    ft.created_at,
    ft.updated_at,
    COALESCE(
      (
        SELECT jsonb_agg(
          jsonb_build_object(
            'id', ftm.id,
            'match_name', ftm.match_name,
            'match_time', ftm.match_time,
            'prediction', ftm.prediction,
            'odds', ftm.odds
          )
        )
        FROM free_ticket_matches ftm
        WHERE ftm.free_ticket_id = ft.id
      ),
      '[]'::jsonb
    ) as matches
  FROM free_tickets ft
  ORDER BY ft.created_at DESC
  LIMIT 10;
END;
$$;

-- Enable realtime for notifications
ALTER TABLE notifications REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;

-- Enable realtime for tickets
ALTER TABLE tickets REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE tickets;

-- Enable realtime for free_tickets
ALTER TABLE free_tickets REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE free_tickets;
