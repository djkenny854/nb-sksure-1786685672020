-- Fix RLS policy for system_settings table to allow read access
-- This will stop the 406 errors in console

-- Drop existing restrictive policy if it exists
DROP POLICY IF EXISTS "Allow read access to system settings" ON system_settings;

-- Create a policy that allows everyone to read system settings
CREATE POLICY "Allow read access to system settings"
ON system_settings
FOR SELECT
TO authenticated, anon
USING (true);

-- Also ensure the maintenance_mode setting exists
INSERT INTO system_settings (key, value, description)
VALUES ('maintenance_mode', 'false', 'Enable/disable maintenance mode')
ON CONFLICT (key) DO NOTHING;