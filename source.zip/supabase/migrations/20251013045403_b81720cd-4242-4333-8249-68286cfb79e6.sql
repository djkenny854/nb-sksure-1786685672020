-- Update cleanup function to handle CANCELLED transactions properly
CREATE OR REPLACE FUNCTION public.cleanup_old_pending_transactions()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Mark transactions older than 30 minutes as expired (excluding CANCELLED ones)
  UPDATE pesapal_transactions
  SET 
    status = 'EXPIRED',
    updated_at = NOW()
  WHERE 
    status = 'pending' 
    AND created_at < NOW() - INTERVAL '30 minutes';
END;
$function$;